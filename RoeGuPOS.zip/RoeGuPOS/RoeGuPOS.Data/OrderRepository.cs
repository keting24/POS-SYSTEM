using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Text;
using RoeGuPOS.Domain;

namespace RoeGuPOS.Data
{
    /// <summary>Creates orders through dbo.usp_Order_Create (one transaction: order, lines, stock, log).</summary>
    public sealed class OrderRepository
    {
        /// <summary>Returns the new OrderId. The procedure re-checks stock, prices, discount and payment.</summary>
        public int Create(int userId, int? customerId, string paymentMethod, decimal discount,
                          decimal taxRate, decimal amountPaid, IEnumerable<CartLine> lines,
                          int pointsToRedeem = 0, decimal pointValue = 1m, decimal earnRate = 0m,
                          decimal memberDiscountPercent = 0m)
        {
            // Only integers go into the XML, so no escaping is needed.
            var xml = new StringBuilder("<Items>");
            foreach (var l in lines)
            {
                xml.Append("<Item ProductId=\"")
                   .Append(l.ProductId.ToString(CultureInfo.InvariantCulture))
                   .Append("\" Quantity=\"")
                   .Append(l.Quantity.ToString(CultureInfo.InvariantCulture))
                   .Append("\"/>");
            }
            xml.Append("</Items>");

            using (var c = Db.Open())
            using (var cmd = Db.Proc(c, "dbo.usp_Order_Create"))
            {
                var ps = cmd.Parameters;
                ps.Add("@UserId", SqlDbType.Int).Value = userId;
                ps.Add("@CustomerId", SqlDbType.Int).Value = customerId.HasValue ? (object)customerId.Value : DBNull.Value;
                ps.Add("@PaymentMethod", SqlDbType.NVarChar, 20).Value = paymentMethod;
                ps.Add(Db.Money("@DiscountAmount", discount));
                ps.Add(new SqlParameter("@TaxRate", SqlDbType.Decimal) { Precision = 5, Scale = 2, Value = taxRate });
                ps.Add(Db.Money("@AmountPaid", amountPaid));
                ps.Add("@ItemsXml", SqlDbType.Xml).Value = xml.ToString();
                ps.Add("@PointsToRedeem", SqlDbType.Int).Value = pointsToRedeem;
                ps.Add(Db.Money("@PointValue", pointValue));
                ps.Add(Db.Money("@EarnRate", earnRate));
                ps.Add(new SqlParameter("@MemberDiscountPct", SqlDbType.Decimal) { Precision = 5, Scale = 2, Value = memberDiscountPercent });
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        /// <summary>Loads a finished order with its lines, for the receipt.</summary>
        public Order Get(int orderId)
        {
            const string headSql = @"
SELECT o.OrderId, o.OrderNumber, o.OrderDate, u.FullName AS CashierName, cu.FullName AS CustomerName,
       o.Subtotal, o.TaxAmount, o.DiscountAmount, o.Total, o.PaymentMethod, o.AmountPaid, o.ChangeDue,
       o.PointsRedeemed, o.PointsEarned, cu.LoyaltyPoints AS CustomerPoints
FROM dbo.Orders o
JOIN dbo.Users u ON u.UserId = o.UserId
LEFT JOIN dbo.Customers cu ON cu.CustomerId = o.CustomerId
WHERE o.OrderId = @OrderId;";
            const string lineSql = @"
SELECT p.Name, d.Quantity, d.UnitPrice, d.LineTotal, COALESCE(d.ListPrice, d.UnitPrice) * d.Quantity AS ListTotal
FROM dbo.OrderDetails d
JOIN dbo.Products p ON p.ProductId = d.ProductId
WHERE d.OrderId = @OrderId
ORDER BY d.OrderDetailId;";

            using (var c = Db.Open())
            {
                Order order;
                using (var cmd = new SqlCommand(headSql, c))
                {
                    cmd.Parameters.Add("@OrderId", SqlDbType.Int).Value = orderId;
                    using (var r = cmd.ExecuteReader())
                    {
                        if (!r.Read()) throw new InvalidOperationException("Order not found.");
                        order = new Order
                        {
                            OrderId = (int)r["OrderId"],
                            OrderNumber = (string)r["OrderNumber"],
                            OrderDate = (DateTime)r["OrderDate"],
                            CashierName = (string)r["CashierName"],
                            CustomerName = r["CustomerName"] as string,
                            Subtotal = (decimal)r["Subtotal"],
                            TaxAmount = (decimal)r["TaxAmount"],
                            DiscountAmount = (decimal)r["DiscountAmount"],
                            Total = (decimal)r["Total"],
                            PaymentMethod = (string)r["PaymentMethod"],
                            AmountPaid = (decimal)r["AmountPaid"],
                            ChangeDue = (decimal)r["ChangeDue"],
                            PointsRedeemed = (int)r["PointsRedeemed"],
                            PointsEarned = (int)r["PointsEarned"],
                            CustomerPoints = Convert.IsDBNull(r["CustomerPoints"]) ? 0 : (int)r["CustomerPoints"]
                        };
                    }
                }

                using (var cmd = new SqlCommand(lineSql, c))
                {
                    cmd.Parameters.Add("@OrderId", SqlDbType.Int).Value = orderId;
                    using (var r = cmd.ExecuteReader())
                    {
                        while (r.Read())
                        {
                            order.Lines.Add(new OrderLine
                            {
                                Name = (string)r["Name"],
                                Quantity = (int)r["Quantity"],
                                UnitPrice = (decimal)r["UnitPrice"],
                                LineTotal = (decimal)r["LineTotal"],
                                ListTotal = (decimal)r["ListTotal"]
                            });
                        }
                    }
                }
                return order;
            }
        }
    }
}
