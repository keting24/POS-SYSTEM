using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using RoeGuPOS.Domain;

namespace RoeGuPOS.Data
{
    internal static class SqlText
    {
        /// <summary>Escapes LIKE wildcards; use with ESCAPE N'\'.</summary>
        public static string EscapeLike(string s)
        {
            return (s ?? string.Empty).Replace(@"\", @"\\").Replace("%", @"\%").Replace("_", @"\_").Replace("[", @"\[");
        }

        public static object OrNull(string s)
        {
            return string.IsNullOrEmpty(s) ? (object)DBNull.Value : s;
        }
    }

    public sealed class CategoryRepository
    {
        public List<CategoryInfo> GetAll()
        {
            const string sql = @"
SELECT c.CategoryId, c.Name, c.Description,
       (SELECT COUNT(*) FROM dbo.Products p WHERE p.CategoryId = c.CategoryId) AS ProductCount
FROM dbo.Categories c
ORDER BY c.Name;";
            var list = new List<CategoryInfo>();
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    list.Add(new CategoryInfo
                    {
                        CategoryId = (int)r["CategoryId"],
                        Name = (string)r["Name"],
                        Description = r["Description"] as string,
                        ProductCount = (int)r["ProductCount"]
                    });
                }
            }
            return list;
        }

        public int Insert(string name, string description)
        {
            const string sql = @"INSERT dbo.Categories (Name, Description) VALUES (@Name, @Description);
SELECT CAST(SCOPE_IDENTITY() AS INT);";
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 100).Value = name;
                cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 200).Value = SqlText.OrNull(description);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public int Update(int id, string name, string description)
        {
            const string sql = "UPDATE dbo.Categories SET Name = @Name, Description = @Description WHERE CategoryId = @Id;";
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 100).Value = name;
                cmd.Parameters.Add("@Description", SqlDbType.NVarChar, 200).Value = SqlText.OrNull(description);
                return cmd.ExecuteNonQuery();
            }
        }

        /// <summary>Deletes only an empty category. Returns 0 rows if it has products or no longer exists.</summary>
        public int Delete(int id)
        {
            const string sql = @"DELETE FROM dbo.Categories
WHERE CategoryId = @Id AND NOT EXISTS (SELECT 1 FROM dbo.Products WHERE CategoryId = @Id);";
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                return cmd.ExecuteNonQuery();
            }
        }
    }

    public sealed class CustomerRepository
    {
        public List<Customer> Search(string text)
        {
            text = (text ?? string.Empty).Trim();
            if (text.Length > 100) text = text.Substring(0, 100);

            const string sql = @"
SELECT TOP (300) CustomerId, FullName, Phone, Email, Address, LoyaltyPoints
FROM dbo.Customers
WHERE @Search = N'' OR FullName LIKE @Like ESCAPE N'\' OR Phone LIKE @Like ESCAPE N'\' OR Email LIKE @Like ESCAPE N'\'
ORDER BY FullName;";

            var list = new List<Customer>();
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                cmd.Parameters.Add("@Search", SqlDbType.NVarChar, 100).Value = text;
                cmd.Parameters.Add("@Like", SqlDbType.NVarChar, 300).Value = "%" + SqlText.EscapeLike(text) + "%";
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new Customer
                        {
                            CustomerId = (int)r["CustomerId"],
                            FullName = (string)r["FullName"],
                            Phone = r["Phone"] as string,
                            Email = r["Email"] as string,
                            Address = r["Address"] as string,
                            LoyaltyPoints = (int)r["LoyaltyPoints"]
                        });
                    }
                }
            }
            return list;
        }

        public int Insert(Customer cu)
        {
            const string sql = @"INSERT dbo.Customers (FullName, Phone, Email, Address) VALUES (@FullName, @Phone, @Email, @Address);
SELECT CAST(SCOPE_IDENTITY() AS INT);";
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                AddFields(cmd, cu);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        public int Update(Customer cu)
        {
            const string sql = "UPDATE dbo.Customers SET FullName = @FullName, Phone = @Phone, Email = @Email, Address = @Address WHERE CustomerId = @Id;";
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                AddFields(cmd, cu);
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = cu.CustomerId;
                return cmd.ExecuteNonQuery();
            }
        }

        /// <summary>Deletes only a customer with no orders. Returns 0 rows otherwise.</summary>
        public int Delete(int id)
        {
            // A customer with no orders may still have manual point adjustments; clear those first.
            // NOCOUNT keeps the first DELETE out of the returned row count.
            const string sql = @"
SET NOCOUNT ON;
DELETE FROM dbo.LoyaltyLog
WHERE CustomerId = @Id AND NOT EXISTS (SELECT 1 FROM dbo.Orders WHERE CustomerId = @Id);
SET NOCOUNT OFF;
DELETE FROM dbo.Customers
WHERE CustomerId = @Id AND NOT EXISTS (SELECT 1 FROM dbo.Orders WHERE CustomerId = @Id);";
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                return cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Adds (positive) or removes (negative) points and writes the ledger row, in one transaction.
        /// Returns the new balance, or -1 when the customer is missing or the balance would go below zero.
        /// </summary>
        public int AdjustPoints(int customerId, int delta, string reason, int userId)
        {
            const string updateSql = @"
UPDATE dbo.Customers
SET LoyaltyPoints = LoyaltyPoints + @Delta
OUTPUT inserted.LoyaltyPoints
WHERE CustomerId = @Id AND LoyaltyPoints + @Delta >= 0;";
            const string logSql = @"
INSERT dbo.LoyaltyLog (CustomerId, OrderId, Points, Reason, UserId)
VALUES (@Id, NULL, @Delta, @Reason, @UserId);";

            using (var c = Db.Open())
            using (var tx = c.BeginTransaction())
            {
                object balance;
                using (var cmd = new SqlCommand(updateSql, c, tx))
                {
                    cmd.Parameters.Add("@Id", SqlDbType.Int).Value = customerId;
                    cmd.Parameters.Add("@Delta", SqlDbType.Int).Value = delta;
                    balance = cmd.ExecuteScalar();
                }
                if (balance == null) { tx.Rollback(); return -1; }

                using (var cmd = new SqlCommand(logSql, c, tx))
                {
                    cmd.Parameters.Add("@Id", SqlDbType.Int).Value = customerId;
                    cmd.Parameters.Add("@Delta", SqlDbType.Int).Value = delta;
                    cmd.Parameters.Add("@Reason", SqlDbType.NVarChar, 200).Value = reason;
                    cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
                    cmd.ExecuteNonQuery();
                }
                tx.Commit();
                return Convert.ToInt32(balance);
            }
        }

        public List<LoyaltyMovement> PointsHistory(int customerId)
        {
            const string sql = @"
SELECT TOP (200) l.CreatedAt, l.Points, l.Reason, ISNULL(u.FullName, N'') AS UserName
FROM dbo.LoyaltyLog l
LEFT JOIN dbo.Users u ON u.UserId = l.UserId
WHERE l.CustomerId = @Id
ORDER BY l.CreatedAt DESC, l.LogId DESC;";

            var list = new List<LoyaltyMovement>();
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = customerId;
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new LoyaltyMovement
                        {
                            CreatedAt = (DateTime)r["CreatedAt"],
                            Points = (int)r["Points"],
                            Reason = (string)r["Reason"],
                            UserName = (string)r["UserName"]
                        });
                    }
                }
            }
            return list;
        }

        private static void AddFields(SqlCommand cmd, Customer cu)
        {
            cmd.Parameters.Add("@FullName", SqlDbType.NVarChar, 100).Value = cu.FullName;
            cmd.Parameters.Add("@Phone", SqlDbType.NVarChar, 30).Value = SqlText.OrNull(cu.Phone);
            cmd.Parameters.Add("@Email", SqlDbType.NVarChar, 120).Value = SqlText.OrNull(cu.Email);
            cmd.Parameters.Add("@Address", SqlDbType.NVarChar, 250).Value = SqlText.OrNull(cu.Address);
        }
    }

    public sealed class StockHistoryRepository
    {
        /// <summary>Newest first. Pass a product id to see one product, or null for all products.</summary>
        public List<StockMovement> Get(int? productId, int top)
        {
            const string sql = @"
SELECT TOP (@Top) l.CreatedAt, p.Sku, p.Name, l.ChangeQty, l.Reason, u.FullName
FROM dbo.InventoryLog l
JOIN dbo.Products p ON p.ProductId = l.ProductId
JOIN dbo.Users u ON u.UserId = l.UserId
WHERE (@ProductId IS NULL OR l.ProductId = @ProductId)
ORDER BY l.CreatedAt DESC, l.LogId DESC;";

            var list = new List<StockMovement>();
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                cmd.Parameters.Add("@Top", SqlDbType.Int).Value = top;
                cmd.Parameters.Add("@ProductId", SqlDbType.Int).Value = productId.HasValue ? (object)productId.Value : DBNull.Value;
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new StockMovement
                        {
                            CreatedAt = (DateTime)r["CreatedAt"],
                            Sku = (string)r["Sku"],
                            ProductName = (string)r["Name"],
                            ChangeQty = (int)r["ChangeQty"],
                            Reason = (string)r["Reason"],
                            UserName = (string)r["FullName"]
                        });
                    }
                }
            }
            return list;
        }
    }
}
