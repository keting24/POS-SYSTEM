using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace RoeGuPOS.Data
{
    /// <summary>Shared connection helpers. The connection string name is "RoeGuPOS" (see App.config).</summary>
    public static class Db
    {
        public static string ConnectionString
        {
            get
            {
                var cs = ConfigurationManager.ConnectionStrings["RoeGuPOS"];
                if (cs == null || string.IsNullOrWhiteSpace(cs.ConnectionString))
                    throw new ConfigurationErrorsException("Connection string 'RoeGuPOS' was not found in App.config.");
                return cs.ConnectionString;
            }
        }

        public static SqlConnection Open()
        {
            var connection = new SqlConnection(ConnectionString);
            connection.Open();
            return connection;
        }

        /// <summary>Creates a stored-procedure command on an open connection.</summary>
        public static SqlCommand Proc(SqlConnection connection, string name)
        {
            return new SqlCommand(name, connection) { CommandType = CommandType.StoredProcedure };
        }

        public static SqlParameter Money(string name, decimal value)
        {
            return new SqlParameter(name, SqlDbType.Decimal) { Precision = 18, Scale = 2, Value = value };
        }
    }
}
