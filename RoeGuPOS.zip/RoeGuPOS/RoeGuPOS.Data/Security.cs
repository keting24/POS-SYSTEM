using System;
using System.Security.Cryptography;
using System.Text;

namespace RoeGuPOS.Data
{
    /// <summary>
    /// Matches the scheme used by Database/RoeGuPOS.sql:
    /// PasswordHash = uppercase hex of SHA-256(Salt + Password).
    /// </summary>
    public static class PasswordHasher
    {
        public static string Hash(string salt, string password)
        {
            using (var sha = SHA256.Create())
            {
                var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(salt + password));
                var sb = new StringBuilder(bytes.Length * 2);
                foreach (var b in bytes) sb.Append(b.ToString("X2"));
                return sb.ToString();
            }
        }

        public static bool Verify(string password, string salt, string expectedHash)
        {
            if (password == null || salt == null || expectedHash == null) return false;
            return string.Equals(Hash(salt, password), expectedHash, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>32-character uppercase hex salt, for creating users later.</summary>
        public static string NewSalt()
        {
            var bytes = new byte[16];
            using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(bytes);
            var sb = new StringBuilder(32);
            foreach (var b in bytes) sb.Append(b.ToString("X2"));
            return sb.ToString();
        }
    }
}
