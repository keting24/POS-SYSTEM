using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using RoeGuPOS.Domain;

namespace RoeGuPOS.Data
{
    public sealed class UserRepository
    {
        /// <summary>
        /// Returns the user when the username exists, is active and the password matches; otherwise null.
        /// Uses dbo.usp_Login, then dbo.usp_User_TouchLogin on success.
        /// </summary>
        public User Login(string username, string password)
        {
            using (var c = Db.Open())
            {
                User user;
                string hash, salt;

                using (var cmd = Db.Proc(c, "dbo.usp_Login"))
                {
                    cmd.Parameters.Add("@Username", SqlDbType.NVarChar, 50).Value = username;
                    using (var r = cmd.ExecuteReader())
                    {
                        if (!r.Read()) return null;
                        hash = (string)r["PasswordHash"];
                        salt = (string)r["Salt"];
                        user = new User
                        {
                            UserId = (int)r["UserId"],
                            Username = (string)r["Username"],
                            FullName = (string)r["FullName"],
                            RoleId = (int)r["RoleId"],
                            RoleName = (string)r["RoleName"],
                            IsActive = (bool)r["IsActive"]
                        };
                    }
                }

                if (!user.IsActive) return null;
                if (!PasswordHasher.Verify(password, salt, hash)) return null;

                using (var touch = Db.Proc(c, "dbo.usp_User_TouchLogin"))
                {
                    touch.Parameters.Add("@UserId", SqlDbType.Int).Value = user.UserId;
                    touch.ExecuteNonQuery();
                }
                return user;
            }
        }
    }

    public sealed class ProductRepository
    {
        // Read query is parameterized; write operations go through the stored procedures.
        private const string ListSql = @"
SELECT p.ProductId, p.Sku, p.Barcode, p.Name, p.CategoryId, c.Name AS CategoryName,
       p.Price, p.Cost, p.StockQty, p.ReorderLevel, p.IsActive, p.BulkMinQty, p.BulkPrice
FROM dbo.Products p
JOIN dbo.Categories c ON c.CategoryId = p.CategoryId
WHERE (@IncludeInactive = 1 OR p.IsActive = 1)
  AND (@Search = N'' OR p.Sku LIKE @Like ESCAPE N'\' OR p.Barcode LIKE @Like ESCAPE N'\' OR p.Name LIKE @Like ESCAPE N'\' OR c.Name LIKE @Like ESCAPE N'\')
ORDER BY p.Name;";

        public List<Product> GetAll(string search, bool includeInactive)
        {
            search = (search ?? string.Empty).Trim();
            if (search.Length > 100) search = search.Substring(0, 100);

            var list = new List<Product>();
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(ListSql, c))
            {
                cmd.Parameters.Add("@IncludeInactive", SqlDbType.Bit).Value = includeInactive;
                cmd.Parameters.Add("@Search", SqlDbType.NVarChar, 100).Value = search;
                cmd.Parameters.Add("@Like", SqlDbType.NVarChar, 300).Value = "%" + EscapeLike(search) + "%";
                using (var r = cmd.ExecuteReader())
                    while (r.Read()) list.Add(Map(r));
            }
            return list;
        }

        public List<Category> GetCategories()
        {
            var list = new List<Category>();
            using (var c = Db.Open())
            using (var cmd = new SqlCommand("SELECT CategoryId, Name FROM dbo.Categories ORDER BY Name;", c))
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                    list.Add(new Category { CategoryId = (int)r["CategoryId"], Name = (string)r["Name"] });
            }
            return list;
        }

        /// <summary>CREATE: dbo.usp_Product_Insert (also writes the "Initial stock" log row).</summary>
        public int Insert(Product p, int userId)
        {
            using (var c = Db.Open())
            using (var cmd = Db.Proc(c, "dbo.usp_Product_Insert"))
            {
                var ps = cmd.Parameters;
                ps.Add("@Sku", SqlDbType.NVarChar, 30).Value = p.Sku;
                ps.Add("@Barcode", SqlDbType.NVarChar, 50).Value = (object)p.Barcode ?? DBNull.Value;
                ps.Add("@Name", SqlDbType.NVarChar, 150).Value = p.Name;
                ps.Add("@CategoryId", SqlDbType.Int).Value = p.CategoryId;
                ps.Add(Db.Money("@Price", p.Price));
                ps.Add(Db.Money("@Cost", p.Cost));
                ps.Add("@StockQty", SqlDbType.Int).Value = p.StockQty;
                ps.Add("@ReorderLevel", SqlDbType.Int).Value = p.ReorderLevel;
                ps.Add("@Image", SqlDbType.VarBinary, -1).Value = (object)p.Image ?? DBNull.Value;
                ps.Add("@UserId", SqlDbType.Int).Value = userId;
                AddBulk(ps, p);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        /// <summary>UPDATE: dbo.usp_Product_Update. Stock is not touched here; use Adjust.</summary>
        public void Update(Product p)
        {
            using (var c = Db.Open())
            using (var cmd = Db.Proc(c, "dbo.usp_Product_Update"))
            {
                var ps = cmd.Parameters;
                ps.Add("@ProductId", SqlDbType.Int).Value = p.ProductId;
                ps.Add("@Sku", SqlDbType.NVarChar, 30).Value = p.Sku;
                ps.Add("@Barcode", SqlDbType.NVarChar, 50).Value = (object)p.Barcode ?? DBNull.Value;
                ps.Add("@Name", SqlDbType.NVarChar, 150).Value = p.Name;
                ps.Add("@CategoryId", SqlDbType.Int).Value = p.CategoryId;
                ps.Add(Db.Money("@Price", p.Price));
                ps.Add(Db.Money("@Cost", p.Cost));
                ps.Add("@ReorderLevel", SqlDbType.Int).Value = p.ReorderLevel;
                ps.Add("@IsActive", SqlDbType.Bit).Value = p.IsActive;
                ps.Add("@Image", SqlDbType.VarBinary, -1).Value = (object)p.Image ?? DBNull.Value;
                ps.Add("@ChangeImage", SqlDbType.Bit).Value = p.ChangeImage;
                AddBulk(ps, p);
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>DELETE (soft): dbo.usp_Product_Delete sets IsActive = 0 so sales history stays intact.</summary>
        public void Delete(int productId)
        {
            using (var c = Db.Open())
            using (var cmd = Db.Proc(c, "dbo.usp_Product_Delete"))
            {
                cmd.Parameters.Add("@ProductId", SqlDbType.Int).Value = productId;
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>Loads one product's picture (null when it has none). Kept out of the list query for speed.</summary>
        public byte[] GetImage(int productId)
        {
            using (var c = Db.Open())
            using (var cmd = new SqlCommand("SELECT Image FROM dbo.Products WHERE ProductId = @Id;", c))
            {
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = productId;
                return cmd.ExecuteScalar() as byte[];
            }
        }

        /// <summary>dbo.usp_Inventory_Adjust: locks the row, blocks negative stock, writes InventoryLog.</summary>
        public int Adjust(int productId, int changeQty, string reason, int userId)
        {
            using (var c = Db.Open())
            using (var cmd = Db.Proc(c, "dbo.usp_Inventory_Adjust"))
            {
                var ps = cmd.Parameters;
                ps.Add("@ProductId", SqlDbType.Int).Value = productId;
                ps.Add("@ChangeQty", SqlDbType.Int).Value = changeQty;
                ps.Add("@Reason", SqlDbType.NVarChar, 200).Value = reason;
                ps.Add("@UserId", SqlDbType.Int).Value = userId;
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        /// <summary>Bulk price parameters; NULL clears the bulk price.</summary>
        private static void AddBulk(SqlParameterCollection ps, Product p)
        {
            ps.Add("@BulkMinQty", SqlDbType.Int).Value = p.BulkMinQty.HasValue ? (object)p.BulkMinQty.Value : DBNull.Value;
            var price = Db.Money("@BulkPrice", p.BulkPrice.HasValue ? p.BulkPrice.Value : 0m);
            if (!p.BulkPrice.HasValue) price.Value = DBNull.Value;
            ps.Add(price);
        }

        private static Product Map(SqlDataReader r)
        {
            return new Product
            {
                ProductId = (int)r["ProductId"],
                Sku = (string)r["Sku"],
                Barcode = r["Barcode"] as string,
                Name = (string)r["Name"],
                CategoryId = (int)r["CategoryId"],
                CategoryName = (string)r["CategoryName"],
                Price = (decimal)r["Price"],
                Cost = (decimal)r["Cost"],
                StockQty = (int)r["StockQty"],
                ReorderLevel = (int)r["ReorderLevel"],
                IsActive = (bool)r["IsActive"],
                BulkMinQty = r["BulkMinQty"] is DBNull ? (int?)null : (int)r["BulkMinQty"],
                BulkPrice = r["BulkPrice"] is DBNull ? (decimal?)null : (decimal)r["BulkPrice"]
            };
        }

        private static string EscapeLike(string s)
        {
            return s.Replace(@"\", @"\\").Replace("%", @"\%").Replace("_", @"\_").Replace("[", @"\[");
        }
    }

    public sealed class ReportRepository
    {
        /// <summary>dbo.usp_Report_Dashboard: today's sales/orders, low-stock count, active products.</summary>
        public DashboardStats Dashboard()
        {
            using (var c = Db.Open())
            using (var cmd = Db.Proc(c, "dbo.usp_Report_Dashboard"))
            using (var r = cmd.ExecuteReader())
            {
                if (!r.Read()) return new DashboardStats();
                return new DashboardStats
                {
                    TodaySales = Convert.ToDecimal(r["TodaySales"]),
                    TodayOrders = Convert.ToInt32(r["TodayOrders"]),
                    LowStockCount = Convert.ToInt32(r["LowStockCount"]),
                    ActiveProducts = Convert.ToInt32(r["ActiveProducts"])
                };
            }
        }

        /// <summary>dbo.usp_Report_LowStock.</summary>
        public List<Product> LowStock()
        {
            var list = new List<Product>();
            using (var c = Db.Open())
            using (var cmd = Db.Proc(c, "dbo.usp_Report_LowStock"))
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    list.Add(new Product
                    {
                        ProductId = (int)r["ProductId"],
                        Sku = (string)r["Sku"],
                        Name = (string)r["Name"],
                        StockQty = (int)r["StockQty"],
                        ReorderLevel = (int)r["ReorderLevel"],
                        IsActive = true
                    });
                }
            }
            return list;
        }
    }
}
