using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using RoeGuPOS.Domain;

namespace RoeGuPOS.Data
{
    /// <summary>User and role maintenance. All queries are parameterized.</summary>
    public sealed class UserAdminRepository
    {
        public List<ManagedUser> GetAll()
        {
            const string sql = @"
SELECT u.UserId, u.Username, u.FullName, u.RoleId, r.RoleName, u.IsActive, u.CreatedAt, u.LastLoginAt
FROM dbo.Users u
JOIN dbo.Roles r ON r.RoleId = u.RoleId
ORDER BY u.Username;";

            var list = new List<ManagedUser>();
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    list.Add(new ManagedUser
                    {
                        UserId = (int)r["UserId"],
                        Username = (string)r["Username"],
                        FullName = (string)r["FullName"],
                        RoleId = (int)r["RoleId"],
                        RoleName = (string)r["RoleName"],
                        IsActive = (bool)r["IsActive"],
                        CreatedAt = (DateTime)r["CreatedAt"],
                        LastLoginAt = r["LastLoginAt"] as DateTime?
                    });
                }
            }
            return list;
        }

        public List<Role> GetRoles()
        {
            var list = new List<Role>();
            using (var c = Db.Open())
            using (var cmd = new SqlCommand("SELECT RoleId, RoleName FROM dbo.Roles ORDER BY RoleId;", c))
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                    list.Add(new Role { RoleId = (int)r["RoleId"], RoleName = (string)r["RoleName"] });
            }
            return list;
        }

        /// <summary>Inserts a user and returns the new UserId. Duplicate usernames raise SQL error 2627/2601.</summary>
        public int Create(string username, string fullName, int roleId, string passwordHash, string salt)
        {
            const string sql = @"
INSERT dbo.Users (Username, PasswordHash, Salt, FullName, RoleId)
VALUES (@Username, @Hash, @Salt, @FullName, @RoleId);
SELECT CAST(SCOPE_IDENTITY() AS INT);";

            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                var ps = cmd.Parameters;
                ps.Add("@Username", SqlDbType.NVarChar, 50).Value = username;
                ps.Add("@Hash", SqlDbType.VarChar, 64).Value = passwordHash;
                ps.Add("@Salt", SqlDbType.VarChar, 32).Value = salt;
                ps.Add("@FullName", SqlDbType.NVarChar, 100).Value = fullName;
                ps.Add("@RoleId", SqlDbType.Int).Value = roleId;
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        /// <summary>
        /// Updates username, name, role and active flag. A duplicate username raises SQL error 2627/2601. The statement itself refuses a change that would leave
        /// the system without an active Admin, and returns 0 rows in that case (or if the user is gone).
        /// </summary>
        public int Update(int userId, string username, string fullName, int roleId, bool isActive)
        {
            const string sql = @"
UPDATE dbo.Users
SET Username = @Username, FullName = @FullName, RoleId = @RoleId, IsActive = @IsActive
WHERE UserId = @UserId
  AND (
        (@IsActive = 1 AND EXISTS (SELECT 1 FROM dbo.Roles WHERE RoleId = @RoleId AND RoleName = N'Admin'))
        OR EXISTS (SELECT 1 FROM dbo.Users u JOIN dbo.Roles r ON r.RoleId = u.RoleId
                   WHERE r.RoleName = N'Admin' AND u.IsActive = 1 AND u.UserId <> @UserId)
      );";

            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                var ps = cmd.Parameters;
                ps.Add("@UserId", SqlDbType.Int).Value = userId;
                ps.Add("@Username", SqlDbType.NVarChar, 50).Value = username;
                ps.Add("@FullName", SqlDbType.NVarChar, 100).Value = fullName;
                ps.Add("@RoleId", SqlDbType.Int).Value = roleId;
                ps.Add("@IsActive", SqlDbType.Bit).Value = isActive;
                return cmd.ExecuteNonQuery();
            }
        }

        public int SetPassword(int userId, string passwordHash, string salt)
        {
            const string sql = "UPDATE dbo.Users SET PasswordHash = @Hash, Salt = @Salt WHERE UserId = @UserId;";
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                cmd.Parameters.Add("@UserId", SqlDbType.Int).Value = userId;
                cmd.Parameters.Add("@Hash", SqlDbType.VarChar, 64).Value = passwordHash;
                cmd.Parameters.Add("@Salt", SqlDbType.VarChar, 32).Value = salt;
                return cmd.ExecuteNonQuery();
            }
        }
    }
}
