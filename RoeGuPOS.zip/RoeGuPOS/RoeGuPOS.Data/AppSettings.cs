using System.Configuration;
using System.Globalization;

namespace RoeGuPOS.Data
{
    /// <summary>Reads simple settings from the startup project's App.config (&lt;appSettings&gt;).</summary>
    public static class AppSettings
    {
        /// <summary>Money spent for each loyalty point earned (default 100). 0 turns earning off.</summary>
        public static decimal LoyaltyEarnRate { get { return Read("LoyaltyEarnRate", 100m, 0m, 1000000m); } }

        /// <summary>Money value of one loyalty point when spent (default 1.00).</summary>
        public static decimal LoyaltyPointValue { get { return Read("LoyaltyPointValue", 1m, 0m, 1000000m); } }

        /// <summary>
        /// Discount in percent that customers (never walk-ins) get on products without a bulk price
        /// (default 5). 0 turns it off. It does not stack with a bulk price: the customer gets the lower price.
        /// </summary>
        public static decimal CustomerDiscountPercent { get { return Read("CustomerDiscountPercent", 5m, 0m, 100m); } }

        private static decimal Read(string key, decimal fallback, decimal min, decimal max)
        {
            var raw = ConfigurationManager.AppSettings[key];
            decimal value;
            if (!decimal.TryParse(raw, NumberStyles.Number, CultureInfo.InvariantCulture, out value)) return fallback;
            if (value < min) return min;
            if (value > max) return max;
            return decimal.Round(value, 2);
        }

        /// <summary>Sales tax percentage, e.g. 12 for 12%. Missing or invalid = 0.</summary>
        public static decimal TaxRate
        {
            get
            {
                var raw = ConfigurationManager.AppSettings["TaxRate"];
                decimal rate;
                if (!decimal.TryParse(raw, NumberStyles.Number, CultureInfo.InvariantCulture, out rate)) return 0m;
                if (rate < 0m) return 0m;
                if (rate > 100m) return 100m;
                return decimal.Round(rate, 2);
            }
        }
    }
}
