using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using RoeGuPOS.Domain;

namespace RoeGuPOS.Data
{
    /// <summary>Sales reports. Uses the existing usp_Report_* procedures plus one parameterized query.</summary>
    public sealed class SalesReportRepository
    {
        public List<DailySalesRow> DailySales(DateTime from, DateTime to)
        {
            var list = new List<DailySalesRow>();
            using (var c = Db.Open())
            using (var cmd = RangeProc(c, "dbo.usp_Report_DailySales", from, to))
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    list.Add(new DailySalesRow
                    {
                        SaleDate = Convert.ToDateTime(r["SaleDate"]),
                        OrderCount = Convert.ToInt32(r["OrderCount"]),
                        Revenue = Convert.ToDecimal(r["Revenue"])
                    });
                }
            }
            return list;
        }

        public List<TopProductRow> TopProducts(DateTime from, DateTime to, int top)
        {
            var list = new List<TopProductRow>();
            using (var c = Db.Open())
            using (var cmd = RangeProc(c, "dbo.usp_Report_TopProducts", from, to))
            {
                cmd.Parameters.Add("@Top", SqlDbType.Int).Value = top;
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new TopProductRow
                        {
                            ProductName = (string)r["ProductName"],
                            QtySold = Convert.ToInt32(r["QtySold"]),
                            Revenue = Convert.ToDecimal(r["Revenue"])
                        });
                    }
                }
            }
            return list;
        }

        public List<CategorySalesRow> SalesByCategory(DateTime from, DateTime to)
        {
            var list = new List<CategorySalesRow>();
            using (var c = Db.Open())
            using (var cmd = RangeProc(c, "dbo.usp_Report_SalesByCategory", from, to))
            using (var r = cmd.ExecuteReader())
            {
                while (r.Read())
                {
                    list.Add(new CategorySalesRow
                    {
                        CategoryName = (string)r["CategoryName"],
                        Revenue = Convert.ToDecimal(r["Revenue"])
                    });
                }
            }
            return list;
        }

        public List<RecentOrderRow> RecentOrders(int top)
        {
            const string sql = @"
SELECT TOP (@Top) o.OrderNumber, o.OrderDate, u.FullName, o.PaymentMethod, o.Total, o.Status
FROM dbo.Orders o
JOIN dbo.Users u ON u.UserId = o.UserId
ORDER BY o.OrderDate DESC, o.OrderId DESC;";

            var list = new List<RecentOrderRow>();
            using (var c = Db.Open())
            using (var cmd = new SqlCommand(sql, c))
            {
                cmd.Parameters.Add("@Top", SqlDbType.Int).Value = top;
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new RecentOrderRow
                        {
                            OrderNumber = (string)r["OrderNumber"],
                            OrderDate = (DateTime)r["OrderDate"],
                            CashierName = (string)r["FullName"],
                            PaymentMethod = (string)r["PaymentMethod"],
                            Total = (decimal)r["Total"],
                            Status = (string)r["Status"]
                        });
                    }
                }
            }
            return list;
        }

        private static SqlCommand RangeProc(SqlConnection c, string name, DateTime from, DateTime to)
        {
            var cmd = Db.Proc(c, name);
            cmd.Parameters.Add("@From", SqlDbType.DateTime).Value = from;
            cmd.Parameters.Add("@To", SqlDbType.DateTime).Value = to;
            return cmd;
        }
    }
}
