using System;

namespace RoeGuPOS.Domain
{
    /// <summary>Role names exactly as seeded in dbo.Roles.</summary>
    public static class RoleNames
    {
        public const string Admin = "Admin";
        public const string Manager = "Manager";
        public const string Cashier = "Cashier";
    }

    public sealed class User
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public bool IsActive { get; set; }

        public bool IsAdmin { get { return RoleName == RoleNames.Admin; } }

        /// <summary>Admin and Manager may work with products and stock.</summary>
        public bool CanManageInventory
        {
            get { return RoleName == RoleNames.Admin || RoleName == RoleNames.Manager; }
        }
    }

    public sealed class Category
    {
        public int CategoryId { get; set; }
        public string Name { get; set; }
        public override string ToString() { return Name; }
    }

    public sealed class Product
    {
        public int ProductId { get; set; }
        public string Sku { get; set; }
        public string Barcode { get; set; }
        public string Name { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public decimal Price { get; set; }
        public decimal Cost { get; set; }
        public int StockQty { get; set; }
        public int ReorderLevel { get; set; }
        public bool IsActive { get; set; }

        /// <summary>Bulk price: buy at least BulkMinQty and every unit costs BulkPrice. Both null = no bulk price.</summary>
        public int? BulkMinQty { get; set; }
        public decimal? BulkPrice { get; set; }

        public bool HasBulkPrice { get { return BulkMinQty.HasValue && BulkPrice.HasValue; } }

        /// <summary>Short text for grids, e.g. "10+ @ 45.00" (empty when there is no bulk price).</summary>
        public string BulkText
        {
            get { return HasBulkPrice ? BulkMinQty.Value + "+ @ " + Currency.Format(BulkPrice.Value) : string.Empty; }
        }

        /// <summary>Picture bytes (PNG). Not loaded with the product list; fetched when a product is edited.</summary>
        public byte[] Image { get; set; }
        /// <summary>True when Image should be written (set or cleared) on save.</summary>
        public bool ChangeImage { get; set; }

        public bool IsLowStock { get { return IsActive && StockQty <= ReorderLevel; } }
    }

    public sealed class DashboardStats
    {
        public decimal TodaySales { get; set; }
        public int TodayOrders { get; set; }
        public int LowStockCount { get; set; }
        public int ActiveProducts { get; set; }
    }
}
