using System;

namespace RoeGuPOS.Domain
{
    public sealed class Role
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public override string ToString() { return RoleName; }
    }

    /// <summary>A user as shown in User Administration. Never carries the password hash or salt.</summary>
    public sealed class ManagedUser
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? LastLoginAt { get; set; }
    }
}
