using System;

namespace RoeGuPOS.Domain
{
    /// <summary>One day of completed sales (usp_Report_DailySales).</summary>
    public sealed class DailySalesRow
    {
        public DateTime SaleDate { get; set; }
        public int OrderCount { get; set; }
        public decimal Revenue { get; set; }
    }

    /// <summary>A best-selling product (usp_Report_TopProducts).</summary>
    public sealed class TopProductRow
    {
        public string ProductName { get; set; }
        public int QtySold { get; set; }
        public decimal Revenue { get; set; }
    }

    /// <summary>Revenue per category (usp_Report_SalesByCategory) with its share of the total.</summary>
    public sealed class CategorySalesRow
    {
        public string CategoryName { get; set; }
        public decimal Revenue { get; set; }
        /// <summary>Percent of all category revenue in the period, 0-100.</summary>
        public decimal Share { get; set; }
    }

    /// <summary>A line in the dashboard's "Recent orders" list.</summary>
    public sealed class RecentOrderRow
    {
        public string OrderNumber { get; set; }
        public DateTime OrderDate { get; set; }
        public string CashierName { get; set; }
        public string PaymentMethod { get; set; }
        public decimal Total { get; set; }
        public string Status { get; set; }
    }
}
