using System;

namespace RoeGuPOS.Domain
{
    /// <summary>A category with the number of products in it (Category Management).</summary>
    public sealed class CategoryInfo
    {
        public int CategoryId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int ProductCount { get; set; }
    }

    public sealed class Customer
    {
        public int CustomerId { get; set; }
        public string FullName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        /// <summary>Current loyalty balance. Changed only by sales and by staff adjustments.</summary>
        public int LoyaltyPoints { get; set; }
    }

    /// <summary>One row of dbo.LoyaltyLog.</summary>
    public sealed class LoyaltyMovement
    {
        public DateTime CreatedAt { get; set; }
        /// <summary>Positive = earned or added, negative = redeemed or removed.</summary>
        public int Points { get; set; }
        public string Reason { get; set; }
        public string UserName { get; set; }
    }

    /// <summary>One row of dbo.InventoryLog with readable names.</summary>
    public sealed class StockMovement
    {
        public DateTime CreatedAt { get; set; }
        public string Sku { get; set; }
        public string ProductName { get; set; }
        public int ChangeQty { get; set; }
        public string Reason { get; set; }
        public string UserName { get; set; }
    }
}
