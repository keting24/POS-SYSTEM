using System;
using System.Collections.Generic;

namespace RoeGuPOS.Domain
{
    /// <summary>One product line in the shopping cart. Prices shown here are for display only;
    /// the database always re-reads the real price when the order is created.</summary>
    public sealed class CartLine
    {
        public int ProductId { get; set; }
        public string Sku { get; set; }
        public string Name { get; set; }
        /// <summary>The normal price of one unit.</summary>
        public decimal RegularPrice { get; set; }
        /// <summary>Bulk price rule copied from the product (both null = none).</summary>
        public int? BulkMinQty { get; set; }
        public decimal? BulkPrice { get; set; }
        public int Quantity { get; set; }
        public int StockQty { get; set; }
        /// <summary>Customer prices (bulk and member discount) are for customers only:
        /// true once a customer is chosen for the sale, never for walk-ins.</summary>
        public bool BulkAllowed { get; set; }
        /// <summary>Customer discount in percent (App.config CustomerDiscountPercent). 0 = none.</summary>
        public decimal MemberDiscountPercent { get; set; }

        /// <summary>Regular price minus the customer discount (rounded to 2 decimals like the database).</summary>
        public decimal MemberPrice
        {
            get
            {
                if (!BulkAllowed || MemberDiscountPercent <= 0m) return RegularPrice;
                return Math.Round(RegularPrice * (100m - MemberDiscountPercent) / 100m, 2, MidpointRounding.AwayFromZero);
            }
        }

        public bool BulkApplied
        {
            get { return BulkAllowed && BulkMinQty.HasValue && BulkPrice.HasValue && Quantity >= BulkMinQty.Value; }
        }

        /// <summary>The price charged per unit: the lowest of the regular price, the customer-discount price
        /// and (once the quantity reaches the minimum) the bulk price. Discounts do not stack.</summary>
        public decimal UnitPrice
        {
            get
            {
                var price = MemberPrice;
                if (BulkApplied && BulkPrice.Value < price) price = BulkPrice.Value;
                return price;
            }
        }

        public decimal LineTotal { get { return UnitPrice * Quantity; } }

        /// <summary>What you save on this line compared with the regular price.</summary>
        public decimal Savings { get { return (RegularPrice - UnitPrice) * Quantity; } }

        /// <summary>Hint shown in the cart: which customer price applies, or how a walk-in could get one.</summary>
        public string PriceNote
        {
            get
            {
                bool hasBulk = BulkMinQty.HasValue && BulkPrice.HasValue;
                bool hasMember = MemberDiscountPercent > 0m;
                if (!hasBulk && !hasMember) return string.Empty;

                if (!BulkAllowed)
                {
                    var offers = new List<string>();
                    if (hasMember) offers.Add(MemberDiscountPercent.ToString("0.##") + "% off");
                    if (hasBulk) offers.Add(BulkMinQty.Value + "+ @ " + Currency.Format(BulkPrice.Value));
                    return "Customers: " + string.Join(", ", offers.ToArray());
                }

                if (BulkApplied && BulkPrice.Value <= MemberPrice) return "Bulk price";
                var note = hasMember ? "Customer -" + MemberDiscountPercent.ToString("0.##") + "%" : string.Empty;
                if (hasBulk && !BulkApplied)
                    note += (note.Length > 0 ? "; " : string.Empty) + "Buy " + BulkMinQty.Value + "+ for " + Currency.Format(BulkPrice.Value);
                return note;
            }
        }
    }

    /// <summary>The currency symbol used when the domain builds display text. The app sets it once at startup.</summary>
    public static class Currency
    {
        private static string symbol = string.Empty;

        public static string Symbol
        {
            get { return symbol; }
            set { symbol = value ?? string.Empty; }
        }

        public static string Format(decimal value) { return symbol + value.ToString("N2"); }
    }

    public sealed class OrderTotals
    {
        public decimal Subtotal { get; set; }
        public decimal Discount { get; set; }
        public decimal Tax { get; set; }
        public decimal Total { get; set; }
    }

    public sealed class OrderLine
    {
        public string Name { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal LineTotal { get; set; }
        /// <summary>The line at regular prices (before customer/bulk discounts). Equals LineTotal for old orders.</summary>
        public decimal ListTotal { get; set; }
    }

    /// <summary>A completed order as stored in the database, used for the receipt.</summary>
    public sealed class Order
    {
        public int OrderId { get; set; }
        public string OrderNumber { get; set; }
        public DateTime OrderDate { get; set; }
        public string CashierName { get; set; }
        /// <summary>Null for a walk-in sale.</summary>
        public string CustomerName { get; set; }
        public decimal Subtotal { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal Total { get; set; }
        public string PaymentMethod { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal ChangeDue { get; set; }
        public int PointsRedeemed { get; set; }
        public int PointsEarned { get; set; }
        /// <summary>The customer's balance after this sale (0 for walk-in sales).</summary>
        public int CustomerPoints { get; set; }
        public List<OrderLine> Lines { get; private set; }

        public Order() { Lines = new List<OrderLine>(); }
    }
}
