using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using RoeGuPOS.Data;
using RoeGuPOS.Domain;

namespace RoeGuPOS.Services
{
    /// <summary>
    /// Selling rules: product lookup, cart totals and checkout. Every signed-in active user
    /// (Admin, Manager, Cashier) may sell; the database remains the final authority on stock and prices.
    /// </summary>
    public sealed class SalesService
    {
        public static readonly string[] PaymentMethods = { "Cash", "Card", "Mobile" };

        private readonly User actor;
        private readonly ProductRepository products = new ProductRepository();
        private readonly OrderRepository orders = new OrderRepository();

        public SalesService(User actor)
        {
            if (actor == null) throw new ArgumentNullException("actor");
            if (!actor.IsActive) throw new UnauthorizedAccessException("This account is disabled.");
            this.actor = actor;
        }

        /// <summary>Money value of one loyalty point when spent (App.config LoyaltyPointValue).</summary>
        public decimal PointValue { get { return AppSettings.LoyaltyPointValue; } }

        /// <summary>Money spent per point earned (App.config LoyaltyEarnRate). 0 = no points earned.</summary>
        public decimal EarnRate { get { return AppSettings.LoyaltyEarnRate; } }

        /// <summary>Points earned on an amount (after discounts, before tax). Same rule as the stored procedure.</summary>
        public static int PointsEarned(decimal netAmount, decimal earnRate)
        {
            if (earnRate <= 0m || netAmount <= 0m) return 0;
            return (int)Math.Floor(netAmount / earnRate);
        }

        /// <summary>The most points a customer can spend on this sale: their balance, capped by what is still payable.</summary>
        public static int MaxRedeemable(int balance, decimal netAmount, decimal pointValue)
        {
            if (balance <= 0 || netAmount <= 0m || pointValue <= 0m) return 0;
            return (int)Math.Min((decimal)balance, Math.Floor(netAmount / pointValue));
        }

        /// <summary>Customer discount percent from App.config (CustomerDiscountPercent). Walk-in sales never get it.</summary>
        public decimal MemberDiscountPercent { get { return AppSettings.CustomerDiscountPercent; } }

        /// <summary>Tax percentage from App.config (TaxRate). 0 when not set.</summary>
        public decimal TaxRate { get { return AppSettings.TaxRate; } }

        /// <summary>Active products matching a SKU, barcode or name fragment.</summary>
        public List<Product> Search(string text)
        {
            return products.GetAll(text, false);
        }

        /// <summary>Exact barcode or SKU match (what a scanner types), or null.</summary>
        public Product FindByCode(string code)
        {
            code = (code ?? string.Empty).Trim();
            if (code.Length == 0) return null;
            return products.GetAll(code, false).FirstOrDefault(p =>
                string.Equals(p.Barcode, code, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(p.Sku, code, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>Same rounding as the stored procedure (2 decimals, away from zero).</summary>
        public static OrderTotals Calculate(IEnumerable<CartLine> lines, decimal discount, decimal taxRate)
        {
            decimal subtotal = lines.Sum(l => l.LineTotal);
            if (discount < 0m) discount = 0m;
            if (discount > subtotal) discount = subtotal;
            decimal tax = Math.Round((subtotal - discount) * taxRate / 100m, 2, MidpointRounding.AwayFromZero);
            return new OrderTotals
            {
                Subtotal = subtotal,
                Discount = discount,
                Tax = tax,
                Total = subtotal - discount + tax
            };
        }

        /// <summary>Validates, creates the order in one database transaction and returns it for the receipt.</summary>
        public Order Checkout(IList<CartLine> lines, string paymentMethod, decimal amountPaid, int? customerId = null, int pointsToRedeem = 0)
        {
            if (lines == null || lines.Count == 0)
                throw new InvalidOperationException("The cart is empty.");
            if (lines.Any(l => l.Quantity <= 0))
                throw new InvalidOperationException("Every item needs a quantity of at least 1.");
            if (lines.Any(l => l.Quantity > l.StockQty))
                throw new InvalidOperationException("A quantity in the cart is higher than the stock on hand.");
            if (!PaymentMethods.Contains(paymentMethod))
                throw new InvalidOperationException("Choose a payment method.");

            if (pointsToRedeem < 0)
                throw new InvalidOperationException("Points to use cannot be negative.");
            if (pointsToRedeem > 0 && !customerId.HasValue)
                throw new InvalidOperationException("Choose a customer to use loyalty points.");

            var pointValue = PointValue;
            var pointsDiscount = pointsToRedeem * pointValue;

            var subtotal = lines.Sum(l => l.LineTotal);
            if (pointsDiscount > subtotal)
                throw new InvalidOperationException("The points used cannot be worth more than the subtotal.");

            var rate = TaxRate;
            var totals = Calculate(lines, pointsDiscount, rate);
            if (amountPaid < totals.Total)
                throw new InvalidOperationException("The amount paid is less than the total.");

            try
            {
                int orderId = orders.Create(actor.UserId, customerId, paymentMethod, 0m, rate, amountPaid, lines,
                                           pointsToRedeem, pointValue, EarnRate,
                                           customerId.HasValue ? MemberDiscountPercent : 0m);
                return orders.Get(orderId);
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                throw new InvalidOperationException("The selected customer no longer exists. Choose the customer again.", ex);
            }
            catch (SqlException ex) when (ex.Number >= 50000)
            {
                // e.g. "Insufficient stock for Cola 330ml Can (available: 2)." - written for the user.
                throw new InvalidOperationException(ex.Message, ex);
            }
        }
    }
}
