using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using RoeGuPOS.Data;
using RoeGuPOS.Domain;

namespace RoeGuPOS.Services
{
    /// <summary>Category management. Admin and Manager only.</summary>
    public sealed class CategoryService
    {
        private readonly User actor;
        private readonly CategoryRepository repo = new CategoryRepository();

        public CategoryService(User actor)
        {
            if (actor == null) throw new ArgumentNullException("actor");
            this.actor = actor;
        }

        private void Demand()
        {
            if (!actor.CanManageInventory)
                throw new UnauthorizedAccessException("Your role is not allowed to manage categories.");
        }

        public List<CategoryInfo> List() { Demand(); return repo.GetAll(); }

        /// <summary>Creates (CategoryId == 0) or updates a category. Returns its id.</summary>
        public int Save(CategoryInfo c)
        {
            Demand();
            var name = (c.Name ?? string.Empty).Trim();
            var description = (c.Description ?? string.Empty).Trim();
            if (name.Length == 0) throw new InvalidOperationException("Category name is required.");
            if (name.Length > 100) throw new InvalidOperationException("Category name must be 100 characters or fewer.");
            if (description.Length > 200) throw new InvalidOperationException("Description must be 200 characters or fewer.");
            if (description.Length == 0) description = null;

            try
            {
                if (c.CategoryId == 0) return repo.Insert(name, description);
                if (repo.Update(c.CategoryId, name, description) == 0)
                    throw new InvalidOperationException("That category no longer exists.");
                return c.CategoryId;
            }
            catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
            {
                throw new InvalidOperationException("A category with that name already exists.", ex);
            }
        }

        public void Delete(int categoryId)
        {
            Demand();
            if (repo.Delete(categoryId) == 0)
                throw new InvalidOperationException(
                    "The category was not deleted. It still has products, or it no longer exists. Move its products to another category first.");
        }
    }

    /// <summary>Customer records. Every signed-in user can add and edit; only Admin and Manager can delete.</summary>
    public sealed class CustomerService
    {
        private static readonly Regex PhonePattern = new Regex(@"^[0-9+()\-\s.]{5,30}$", RegexOptions.Compiled);
        private static readonly Regex EmailPattern = new Regex(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.Compiled);

        private readonly User actor;
        private readonly CustomerRepository repo = new CustomerRepository();

        public CustomerService(User actor)
        {
            if (actor == null) throw new ArgumentNullException("actor");
            if (!actor.IsActive) throw new UnauthorizedAccessException("This account is disabled.");
            this.actor = actor;
        }

        public bool CanDelete { get { return actor.CanManageInventory; } }

        public List<Customer> Search(string text) { return repo.Search(text); }

        /// <summary>Creates (CustomerId == 0) or updates a customer. Returns the id.</summary>
        public int Save(Customer c)
        {
            c.FullName = (c.FullName ?? string.Empty).Trim();
            c.Phone = Clean(c.Phone);
            c.Email = Clean(c.Email);
            c.Address = Clean(c.Address);

            if (c.FullName.Length == 0) throw new InvalidOperationException("Customer name is required.");
            if (c.FullName.Length > 100) throw new InvalidOperationException("Name must be 100 characters or fewer.");
            if (c.Phone != null && !PhonePattern.IsMatch(c.Phone))
                throw new InvalidOperationException("Phone can contain digits, spaces, + - ( ) and be 5-30 characters.");
            if (c.Email != null && (c.Email.Length > 120 || !EmailPattern.IsMatch(c.Email)))
                throw new InvalidOperationException("Enter a valid email address (120 characters or fewer).");
            if (c.Address != null && c.Address.Length > 250)
                throw new InvalidOperationException("Address must be 250 characters or fewer.");

            if (c.CustomerId == 0) return repo.Insert(c);
            if (repo.Update(c) == 0) throw new InvalidOperationException("That customer no longer exists.");
            return c.CustomerId;
        }

        public void Delete(int customerId)
        {
            if (!CanDelete) throw new UnauthorizedAccessException("Your role is not allowed to delete customers.");
            if (repo.Delete(customerId) == 0)
                throw new InvalidOperationException("The customer was not deleted. They have past orders, or no longer exist.");
        }

        /// <summary>Adds or removes loyalty points by hand (Admin and Manager). Returns the new balance.</summary>
        public int AdjustPoints(int customerId, int delta, string reason)
        {
            if (!actor.CanManageInventory)
                throw new UnauthorizedAccessException("Your role is not allowed to adjust loyalty points.");
            if (delta == 0) throw new InvalidOperationException("Enter a number of points other than zero.");
            if (delta > 1000000 || delta < -1000000) throw new InvalidOperationException("That is too many points at once.");
            reason = (reason ?? string.Empty).Trim();
            if (reason.Length == 0) throw new InvalidOperationException("A reason is required.");
            if (reason.Length > 180) throw new InvalidOperationException("The reason must be 180 characters or fewer.");

            int balance = repo.AdjustPoints(customerId, delta, "Manual: " + reason, actor.UserId);
            if (balance < 0)
                throw new InvalidOperationException("The points were not changed. The customer may no longer exist, or the balance would go below zero.");
            return balance;
        }

        public List<LoyaltyMovement> PointsHistory(int customerId) { return repo.PointsHistory(customerId); }

        private static string Clean(string s)
        {
            s = (s ?? string.Empty).Trim();
            return s.Length == 0 ? null : s;
        }
    }

    /// <summary>Read-only view of every stock movement (Admin and Manager).</summary>
    public sealed class StockHistoryService
    {
        private readonly User actor;
        private readonly StockHistoryRepository repo = new StockHistoryRepository();

        public StockHistoryService(User actor)
        {
            if (actor == null) throw new ArgumentNullException("actor");
            this.actor = actor;
        }

        public List<StockMovement> Get(int? productId)
        {
            if (!actor.CanManageInventory)
                throw new UnauthorizedAccessException("Your role is not allowed to view stock history.");
            return repo.Get(productId, 500);
        }
    }
}
