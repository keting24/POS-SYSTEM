using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using RoeGuPOS.Data;
using RoeGuPOS.Domain;

namespace RoeGuPOS.Services
{
    public sealed class AuthService
    {
        private readonly UserRepository repo = new UserRepository();

        /// <summary>Returns the authenticated user, or null for any kind of invalid credentials.</summary>
        public User Login(string username, string password)
        {
            username = (username ?? string.Empty).Trim();
            if (username.Length == 0 || string.IsNullOrEmpty(password)) return null;
            return repo.Login(username, password);
        }
    }

    public sealed class DashboardService
    {
        private readonly ReportRepository repo = new ReportRepository();

        public DashboardStats Stats() { return repo.Dashboard(); }
        public List<Product> LowStock() { return repo.LowStock(); }
    }

    /// <summary>
    /// Business rules + authorization for products and stock.
    /// Every call re-checks the actor's role, so hiding a menu is never the only protection.
    /// </summary>
    public sealed class InventoryService
    {
        private readonly User actor;
        private readonly ProductRepository repo = new ProductRepository();

        public InventoryService(User actor)
        {
            if (actor == null) throw new ArgumentNullException("actor");
            this.actor = actor;
        }

        private void Demand()
        {
            if (!actor.CanManageInventory)
                throw new UnauthorizedAccessException("Your role is not allowed to manage inventory.");
        }

        public List<Product> Search(string text, bool includeInactive)
        {
            Demand();
            return repo.GetAll(text, includeInactive);
        }

        public List<Category> Categories()
        {
            Demand();
            return repo.GetCategories();
        }

        /// <summary>The product's picture (PNG bytes), or null when it has none.</summary>
        public byte[] GetImage(int productId)
        {
            Demand();
            return repo.GetImage(productId);
        }

        /// <summary>Creates (ProductId == 0) or updates a product. Returns the product id.</summary>
        public int Save(Product p)
        {
            Demand();
            Normalize(p);
            Validate(p);
            try
            {
                if (p.ProductId == 0) return repo.Insert(p, actor.UserId);
                repo.Update(p);
                return p.ProductId;
            }
            catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
            {
                throw new InvalidOperationException("That SKU or barcode is already used by another product.", ex);
            }
            catch (SqlException ex) when (ex.Number >= 50000)
            {
                throw new InvalidOperationException(ex.Message, ex);
            }
        }

        /// <summary>Soft delete: the product is hidden but past sales stay intact.</summary>
        public void Delete(int productId)
        {
            Demand();
            try { repo.Delete(productId); }
            catch (SqlException ex) when (ex.Number >= 50000)
            {
                throw new InvalidOperationException(ex.Message, ex);
            }
        }

        /// <summary>Adds (positive) or removes (negative) stock. Returns the new stock level.</summary>
        public int AdjustStock(int productId, int change, string reason)
        {
            Demand();
            if (change == 0) throw new InvalidOperationException("Enter a quantity other than zero.");
            reason = (reason ?? string.Empty).Trim();
            if (reason.Length == 0) throw new InvalidOperationException("A reason is required.");
            if (reason.Length > 200) throw new InvalidOperationException("Reason must be 200 characters or fewer.");
            try { return repo.Adjust(productId, change, reason, actor.UserId); }
            catch (SqlException ex) when (ex.Number >= 50000)
            {
                throw new InvalidOperationException(ex.Message, ex);
            }
        }

        private static void Normalize(Product p)
        {
            p.Sku = (p.Sku ?? string.Empty).Trim();
            p.Name = (p.Name ?? string.Empty).Trim();
            // The unique barcode index only ignores NULLs, so blank must become NULL.
            var barcode = (p.Barcode ?? string.Empty).Trim();
            p.Barcode = barcode.Length == 0 ? null : barcode;
        }

        private static void Validate(Product p)
        {
            if (p.Sku.Length == 0) throw new InvalidOperationException("SKU is required.");
            if (p.Sku.Length > 30) throw new InvalidOperationException("SKU must be 30 characters or fewer.");
            if (p.Name.Length == 0) throw new InvalidOperationException("Product name is required.");
            if (p.Name.Length > 150) throw new InvalidOperationException("Product name must be 150 characters or fewer.");
            if (p.Barcode != null && p.Barcode.Length > 50) throw new InvalidOperationException("Barcode must be 50 characters or fewer.");
            if (p.CategoryId <= 0) throw new InvalidOperationException("Choose a category.");
            if (p.Price < 0) throw new InvalidOperationException("Selling price cannot be negative.");
            if (p.Cost < 0) throw new InvalidOperationException("Cost price cannot be negative.");
            if (p.StockQty < 0) throw new InvalidOperationException("Stock cannot be negative.");
            if (p.ReorderLevel < 0) throw new InvalidOperationException("Reorder level cannot be negative.");
            if (p.BulkMinQty.HasValue != p.BulkPrice.HasValue)
                throw new InvalidOperationException("Enter both the bulk quantity and the bulk price, or leave both empty.");
            if (p.BulkMinQty.HasValue && p.BulkMinQty.Value < 2)
                throw new InvalidOperationException("The bulk quantity must be at least 2.");
            if (p.BulkPrice.HasValue && (p.BulkPrice.Value <= 0m || p.BulkPrice.Value >= p.Price))
                throw new InvalidOperationException("The bulk price must be more than 0 and lower than the regular price.");
            if (p.Image != null && p.Image.Length > 2 * 1024 * 1024)
                throw new InvalidOperationException("The picture is too large (limit 2 MB after resizing).");
        }
    }
}
