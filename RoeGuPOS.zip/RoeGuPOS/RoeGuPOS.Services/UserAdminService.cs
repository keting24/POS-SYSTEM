using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text.RegularExpressions;
using RoeGuPOS.Data;
using RoeGuPOS.Domain;

namespace RoeGuPOS.Services
{
    /// <summary>User and role administration. Admin only; every call re-checks the signed-in user's role.</summary>
    public sealed class UserAdminService
    {
        private static readonly Regex UsernamePattern = new Regex(@"^[A-Za-z0-9._-]{3,50}$", RegexOptions.Compiled);
        private readonly User actor;
        private readonly UserAdminRepository repo = new UserAdminRepository();

        public UserAdminService(User actor)
        {
            if (actor == null) throw new ArgumentNullException("actor");
            this.actor = actor;
        }

        private void Demand()
        {
            if (!actor.IsAdmin)
                throw new UnauthorizedAccessException("Only an Admin can manage users.");
        }

        public List<ManagedUser> List() { return List(null); }

        /// <summary>All users, or only those whose username, full name or role contains the text.</summary>
        public List<ManagedUser> List(string search)
        {
            Demand();
            var all = repo.GetAll();
            search = (search ?? string.Empty).Trim();
            if (search.Length == 0) return all;
            return all.Where(u =>
                    Contains(u.Username, search) || Contains(u.FullName, search) || Contains(u.RoleName, search))
                .ToList();
        }

        private static bool Contains(string value, string search)
        {
            return value != null && value.IndexOf(search, StringComparison.OrdinalIgnoreCase) >= 0;
        }
        public List<Role> Roles() { Demand(); return repo.GetRoles(); }

        public int Create(string username, string fullName, int roleId, string password)
        {
            Demand();
            username = (username ?? string.Empty).Trim();
            fullName = (fullName ?? string.Empty).Trim();
            if (!UsernamePattern.IsMatch(username))
                throw new InvalidOperationException("Username must be 3-50 characters: letters, numbers, dot, dash or underscore.");
            ValidateName(fullName);
            if (roleId <= 0) throw new InvalidOperationException("Choose a role.");
            ValidatePassword(password);

            var salt = PasswordHasher.NewSalt();
            var hash = PasswordHasher.Hash(salt, password);
            try
            {
                return repo.Create(username, fullName, roleId, hash, salt);
            }
            catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
            {
                throw new InvalidOperationException("That username is already taken.", ex);
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                throw new InvalidOperationException("The selected role does not exist.", ex);
            }
        }

        public void Update(int userId, string username, string fullName, int roleId, bool isActive)
        {
            Demand();
            username = (username ?? string.Empty).Trim();
            fullName = (fullName ?? string.Empty).Trim();
            if (!UsernamePattern.IsMatch(username))
                throw new InvalidOperationException("Username must be 3-50 characters: letters, numbers, dot, dash or underscore.");
            ValidateName(fullName);
            if (roleId <= 0) throw new InvalidOperationException("Choose a role.");

            if (userId == actor.UserId && (!isActive || roleId != actor.RoleId))
                throw new InvalidOperationException("You cannot disable your own account or change your own role.");

            int rows;
            try { rows = repo.Update(userId, username, fullName, roleId, isActive); }
            catch (SqlException ex) when (ex.Number == 2627 || ex.Number == 2601)
            {
                throw new InvalidOperationException("That username is already taken.", ex);
            }
            catch (SqlException ex) when (ex.Number == 547)
            {
                throw new InvalidOperationException("The selected role does not exist.", ex);
            }

            if (rows == 0)
                throw new InvalidOperationException(
                    "The change was not saved. The user may no longer exist, or it would leave the system without an active Admin.");
        }

        public void ResetPassword(int userId, string newPassword)
        {
            Demand();
            ValidatePassword(newPassword);
            var salt = PasswordHasher.NewSalt();
            var hash = PasswordHasher.Hash(salt, newPassword);
            if (repo.SetPassword(userId, hash, salt) == 0)
                throw new InvalidOperationException("That user no longer exists.");
        }

        private static void ValidateName(string fullName)
        {
            if (fullName.Length == 0) throw new InvalidOperationException("Full name is required.");
            if (fullName.Length > 100) throw new InvalidOperationException("Full name must be 100 characters or fewer.");
        }

        /// <summary>At least 8 characters with a letter and a digit.</summary>
        public static void ValidatePassword(string password)
        {
            if (string.IsNullOrEmpty(password) || password.Length < 8)
                throw new InvalidOperationException("The password must be at least 8 characters.");
            if (password.Length > 100)
                throw new InvalidOperationException("The password must be 100 characters or fewer.");
            if (!password.Any(char.IsLetter) || !password.Any(char.IsDigit))
                throw new InvalidOperationException("The password must contain at least one letter and one number.");
        }
    }
}
