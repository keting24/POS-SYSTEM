using System;
using System.Collections.Generic;
using System.Linq;
using RoeGuPOS.Data;
using RoeGuPOS.Domain;

namespace RoeGuPOS.Services
{
    /// <summary>
    /// Sales reporting. Reports (revenue, best sellers, categories) are limited to Admin and Manager;
    /// the recent-orders list on the dashboard is available to every signed-in user.
    /// </summary>
    public sealed class AnalyticsService
    {
        private const int MaxRangeDays = 366;
        private readonly User actor;
        private readonly SalesReportRepository repo = new SalesReportRepository();

        public AnalyticsService(User actor)
        {
            if (actor == null) throw new ArgumentNullException("actor");
            this.actor = actor;
        }

        private void DemandReports()
        {
            if (!actor.CanManageInventory)
                throw new UnauthorizedAccessException("Your role is not allowed to view sales reports.");
        }

        private static void CheckRange(DateTime from, DateTime to)
        {
            if (from.Date > to.Date)
                throw new InvalidOperationException("The start date must be on or before the end date.");
            if ((to.Date - from.Date).TotalDays > MaxRangeDays)
                throw new InvalidOperationException("Choose a range of one year or less.");
        }

        /// <summary>Daily totals with a row for every day in the range (days without sales show 0).</summary>
        public List<DailySalesRow> Daily(DateTime from, DateTime to)
        {
            DemandReports();
            CheckRange(from, to);
            var byDate = repo.DailySales(from.Date, to.Date).ToDictionary(r => r.SaleDate.Date);

            var result = new List<DailySalesRow>();
            for (var d = from.Date; d <= to.Date; d = d.AddDays(1))
            {
                DailySalesRow row;
                result.Add(byDate.TryGetValue(d, out row) ? row : new DailySalesRow { SaleDate = d });
            }
            return result;
        }

        public List<TopProductRow> TopProducts(DateTime from, DateTime to, int top)
        {
            DemandReports();
            CheckRange(from, to);
            if (top < 1) top = 10;
            if (top > 100) top = 100;
            return repo.TopProducts(from.Date, to.Date, top);
        }

        public List<CategorySalesRow> ByCategory(DateTime from, DateTime to)
        {
            DemandReports();
            CheckRange(from, to);
            var rows = repo.SalesByCategory(from.Date, to.Date);
            decimal total = rows.Sum(r => r.Revenue);
            foreach (var r in rows)
                r.Share = total > 0m ? Math.Round(r.Revenue * 100m / total, 1) : 0m;
            return rows;
        }

        public List<RecentOrderRow> RecentOrders(int count)
        {
            if (count < 1) count = 10;
            if (count > 50) count = 50;
            return repo.RecentOrders(count);
        }
    }
}
