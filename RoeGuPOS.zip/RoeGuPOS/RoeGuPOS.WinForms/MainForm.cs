using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Module 2: application shell with a left sidebar (Dashboard, Inventory, Account) and dashboard metrics.</summary>
    public sealed class MainForm : Form
    {
        private readonly DashboardService dashboard = new DashboardService();
        private readonly User user = AppSession.CurrentUser;

        private readonly Panel sidebar = new Panel();
        private readonly Panel content = new Panel();
        private readonly Panel dashboardView = new Panel();
        private readonly Panel accountView = new Panel();
        private readonly List<Button> navButtons = new List<Button>();
        private readonly DataGridView gridLow = new DataGridView();
        private readonly DataGridView gridRecent = new DataGridView();
        private readonly Label lblSales = new Label();
        private readonly Label lblOrders = new Label();
        private readonly Label lblLow = new Label();
        private readonly Label lblProducts = new Label();
        private Button btnDashboard, btnSale, btnCustomers, btnInventory, btnAnalytics, btnUsers, btnAccount;
        private CustomerForm customersView;
        private UserAdminForm usersView;
        private ProductForm productView;
        private CheckoutForm checkoutView;
        private AnalyticsForm analyticsView;

        /// <summary>True when the user chose Logout (Program then shows the login form again).</summary>
        public bool LoggedOut { get; private set; }

        public MainForm()
        {
            Text = "RoeGuPOS";
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1180, 720);
            MinimumSize = new Size(960, 600);
            Font = Theme.Base(10f);
            BackColor = Theme.Background;

            BuildSidebar();
            BuildDashboardView();
            BuildAccountView();

            content.Dock = DockStyle.Fill;
            content.BackColor = Theme.Background;

            // Docking is applied from the last control added to the first, so Fill goes in first.
            Controls.Add(content);
            Controls.Add(sidebar);

            Shown += (s, e) => ShowDashboard();
        }

        // ---------- sidebar ----------

        private void BuildSidebar()
        {
            sidebar.Dock = DockStyle.Left;
            sidebar.Width = 230;
            sidebar.BackColor = Theme.Slate;

            var footer = new Label
            {
                Dock = DockStyle.Bottom,
                Height = 64,
                ForeColor = Theme.NavText,
                Font = Theme.Base(9f),
                Padding = new Padding(20, 12, 10, 0),
                Text = user == null ? string.Empty : user.FullName + "\n" + user.RoleName
            };

            var brand = new Panel { Dock = DockStyle.Top, Height = 96, BackColor = Theme.Slate };
            brand.Controls.Add(new Label
            {
                Text = "RoeGuPOS",
                Font = Theme.Bold(18f),
                ForeColor = Theme.Peach,
                AutoSize = true,
                Location = new Point(20, 22)
            });
            brand.Controls.Add(new Label
            {
                Text = "Point of Sale",
                Font = Theme.Base(9f),
                ForeColor = Theme.Sage,
                AutoSize = true,
                Location = new Point(22, 58)
            });

            btnDashboard = MakeNav("Dashboard", ShowDashboard);
            btnSale = MakeNav("New Sale", ShowCheckout);
            btnCustomers = MakeNav("Customers", ShowCustomers);
            btnInventory = MakeNav("Inventory", ShowInventory);
            btnAnalytics = MakeNav("Analytics", ShowAnalytics);
            btnUsers = MakeNav("Users", ShowUsers);
            btnAccount = MakeNav("Account", ShowAccount);
            // Hide the module from roles that may not use it; the service layer enforces this too.
            btnInventory.Visible = user != null && user.CanManageInventory;
            btnAnalytics.Visible = user != null && user.CanManageInventory;
            btnUsers.Visible = user != null && user.IsAdmin;

            // Log out sits at the bottom of the sidebar, just above the signed-in user's name.
            var btnSideLogout = new Button
            {
                Text = "Log out",
                Dock = DockStyle.Bottom,
                Height = 52,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(24, 0, 0, 0),
                Font = Theme.Base(11f),
                TabStop = false,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand,
                UseVisualStyleBackColor = false,
                BackColor = Theme.Slate,
                ForeColor = Theme.NavText
            };
            btnSideLogout.FlatAppearance.BorderSize = 0;
            btnSideLogout.FlatAppearance.MouseOverBackColor = Theme.SlateHover;
            btnSideLogout.FlatAppearance.MouseDownBackColor = Theme.SlateHover;
            btnSideLogout.Click += (s, e) =>
            {
                if (MessageBox.Show(this, "Log out of RoeGuPOS?", "Log out",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
                LoggedOut = true;
                Close();
            };

            // Last added is docked first (top-most): brand, Dashboard, Inventory, Account.
            // For the bottom edge the first one docked is lowest, so the footer is added after the Log out button.
            sidebar.Controls.Add(btnSideLogout);
            sidebar.Controls.Add(footer);
            sidebar.Controls.Add(btnAccount);
            sidebar.Controls.Add(btnUsers);
            sidebar.Controls.Add(btnAnalytics);
            sidebar.Controls.Add(btnInventory);
            sidebar.Controls.Add(btnCustomers);
            sidebar.Controls.Add(btnSale);
            sidebar.Controls.Add(btnDashboard);
            sidebar.Controls.Add(brand);
        }

        private Button MakeNav(string text, Action onClick)
        {
            var b = new Button
            {
                Text = text,
                Dock = DockStyle.Top,
                Height = 52,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(24, 0, 0, 0),
                Font = Theme.Base(11f),
                TabStop = false
            };
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.Cursor = Cursors.Hand;
            b.UseVisualStyleBackColor = false;
            b.Click += (s, e) => onClick();
            navButtons.Add(b);
            SetNavStyle(b, false);
            return b;
        }

        private static void SetNavStyle(Button b, bool active)
        {
            b.BackColor = active ? Theme.Rose : Theme.Slate;
            b.ForeColor = active ? Color.White : Theme.NavText;
            b.FlatAppearance.MouseOverBackColor = active ? Theme.Rose : Theme.SlateHover;
            b.FlatAppearance.MouseDownBackColor = active ? Theme.Rose : Theme.SlateHover;
        }

        private void Activate(Button active)
        {
            foreach (var b in navButtons) SetNavStyle(b, b == active);
        }

        // ---------- dashboard ----------

        private void BuildDashboardView()
        {
            dashboardView.Dock = DockStyle.Fill;
            dashboardView.Padding = new Padding(28, 24, 28, 20);
            dashboardView.BackColor = Theme.Background;

            var heading = new Label
            {
                Text = "Dashboard",
                Font = Theme.Bold(20f),
                ForeColor = Theme.Slate,
                AutoSize = true,
                Dock = DockStyle.Top
            };
            var subtitle = new Label
            {
                Text = user == null ? string.Empty : "Welcome back, " + user.FullName,
                ForeColor = Theme.Muted,
                AutoSize = true,
                Dock = DockStyle.Top,
                Padding = new Padding(0, 0, 0, 8)
            };

            var cards = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 120,
                ColumnCount = 4,
                RowCount = 1,
                Padding = new Padding(0, 8, 0, 12)
            };
            for (int i = 0; i < 4; i++) cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            cards.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            cards.Controls.Add(MakeCard("Today's sales", lblSales, Theme.Rose, Color.White), 0, 0);
            cards.Controls.Add(MakeCard("Today's orders", lblOrders, Theme.Sage, Theme.Slate), 1, 0);
            cards.Controls.Add(MakeCard("Low stock items", lblLow, Theme.Coral, Theme.Slate), 2, 0);
            cards.Controls.Add(MakeCard("Active products", lblProducts, Theme.Slate, Theme.Peach), 3, 0);

            var lowTitle = new Label
            {
                Text = "Items at or below reorder level",
                Font = Theme.Bold(12f),
                ForeColor = Theme.Slate,
                AutoSize = true,
                Dock = DockStyle.Top,
                Padding = new Padding(0, 6, 0, 8)
            };

            gridLow.Dock = DockStyle.Fill;
            gridLow.ReadOnly = true;
            gridLow.AllowUserToAddRows = false;
            gridLow.AllowUserToDeleteRows = false;
            gridLow.RowHeadersVisible = false;
            gridLow.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            gridLow.AutoGenerateColumns = false;
            Theme.StyleGrid(gridLow);
            gridLow.Columns.Add(Col("Sku", "SKU", 120));
            gridLow.Columns.Add(Col("Name", "Product", 0));
            gridLow.Columns.Add(Col("StockQty", "In stock", 100));
            gridLow.Columns.Add(Col("ReorderLevel", "Reorder level", 120));
            gridLow.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            var refresh = new Button { Text = "Refresh", Dock = DockStyle.Bottom, Height = 38 };
            Theme.Secondary(refresh);
            refresh.Click += (s, e) => LoadDashboard();

            // Dock order: last added is laid out first.
            ConfigureRecentGrid();
            var recentTitle = new Label
            {
                Text = "Recent orders",
                Font = Theme.Bold(12f),
                ForeColor = Theme.Slate,
                AutoSize = true,
                Dock = DockStyle.Top,
                Padding = new Padding(0, 6, 0, 8)
            };

            var leftPane = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0, 0, 10, 0) };
            leftPane.Controls.Add(gridLow);
            leftPane.Controls.Add(lowTitle);

            var rightPane = new Panel { Dock = DockStyle.Fill, Padding = new Padding(10, 0, 0, 0) };
            rightPane.Controls.Add(gridRecent);
            rightPane.Controls.Add(recentTitle);

            var lower = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1 };
            lower.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            lower.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            lower.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            lower.Controls.Add(leftPane, 0, 0);
            lower.Controls.Add(rightPane, 1, 0);
            dashboardView.Controls.Add(lower);
            dashboardView.Controls.Add(cards);
            dashboardView.Controls.Add(subtitle);
            dashboardView.Controls.Add(heading);
            dashboardView.Controls.Add(refresh);
        }

        private void ConfigureRecentGrid()
        {
            gridRecent.Dock = DockStyle.Fill;
            gridRecent.ReadOnly = true;
            gridRecent.AllowUserToAddRows = false;
            gridRecent.AllowUserToDeleteRows = false;
            gridRecent.RowHeadersVisible = false;
            gridRecent.AutoGenerateColumns = false;
            gridRecent.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Theme.StyleGrid(gridRecent);
            gridRecent.Columns.Add(Col("OrderNumber", "Order", 150));
            gridRecent.Columns.Add(Col("OrderDate", "Date", 130));
            gridRecent.Columns.Add(Col("CashierName", "Cashier", 0));
            gridRecent.Columns.Add(Col("PaymentMethod", "Payment", 80));
            gridRecent.Columns.Add(Col("Total", "Total", 90));
            gridRecent.Columns["OrderDate"].DefaultCellStyle.Format = "g";
            gridRecent.Columns["Total"].DefaultCellStyle.Format = Theme.MoneyFormat;
            gridRecent.Columns["Total"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gridRecent.Columns["CashierName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private static DataGridViewTextBoxColumn Col(string property, string header, int width)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName = property, HeaderText = header, Name = property };
            if (width > 0) c.Width = width;
            return c;
        }

        private static Control MakeCard(string caption, Label value, Color back, Color fore)
        {
            var card = new Panel { Dock = DockStyle.Fill, BackColor = back, Margin = new Padding(0, 0, 14, 0), Padding = new Padding(18, 14, 14, 10) };
            var cap = new Label { Text = caption, ForeColor = fore, Font = Theme.Base(10f), AutoSize = true, Dock = DockStyle.Top };
            value.ForeColor = fore;
            value.Font = Theme.Bold(24f);
            value.AutoSize = false;
            value.Dock = DockStyle.Fill;
            value.TextAlign = ContentAlignment.MiddleLeft;
            value.Text = "-";
            card.Controls.Add(value);
            card.Controls.Add(cap);
            return card;
        }

        // ---------- account ----------

        private void BuildAccountView()
        {
            accountView.Dock = DockStyle.Fill;
            accountView.Padding = new Padding(28, 24, 28, 20);
            accountView.BackColor = Theme.Background;

            var heading = new Label
            {
                Text = "Account",
                Font = Theme.Bold(20f),
                ForeColor = Theme.Slate,
                AutoSize = true,
                Dock = DockStyle.Top
            };

            var card = new Panel
            {
                BackColor = Theme.Surface,
                Size = new Size(440, 270),
                Location = new Point(28, 80)
            };
            card.Controls.Add(new Panel { Dock = DockStyle.Top, Height = 6, BackColor = Theme.Rose });

            AddInfo(card, "Full name", user == null ? "" : user.FullName, 26);
            AddInfo(card, "Username", user == null ? "" : user.Username, 82);
            AddInfo(card, "Role", user == null ? "" : user.RoleName, 138);

            var btnLogout = new Button { Text = "Logout", Location = new Point(24, 208), Size = new Size(190, 40) };
            Theme.Primary(btnLogout);
            btnLogout.Click += (s, e) => { LoggedOut = true; Close(); };

            var btnExit = new Button { Text = "Exit application", Location = new Point(226, 208), Size = new Size(190, 40) };
            Theme.Dark(btnExit);
            btnExit.Click += (s, e) => { LoggedOut = false; Close(); };

            card.Controls.Add(btnLogout);
            card.Controls.Add(btnExit);

            accountView.Controls.Add(card);
            accountView.Controls.Add(heading);
        }

        private static void AddInfo(Panel card, string caption, string value, int y)
        {
            card.Controls.Add(new Label { Text = caption, ForeColor = Theme.Muted, Font = Theme.Base(9f), AutoSize = true, Location = new Point(24, y) });
            card.Controls.Add(new Label { Text = value, ForeColor = Theme.Slate, Font = Theme.Bold(13f), AutoSize = true, Location = new Point(24, y + 18) });
        }

        // ---------- navigation ----------

        private void ShowDashboard()
        {
            Activate(btnDashboard);
            SwapContent(dashboardView);
            LoadDashboard();
        }

        private void ShowInventory()
        {
            if (user == null || !user.CanManageInventory) return;
            Activate(btnInventory);
            if (productView == null || productView.IsDisposed)
            {
                productView = new ProductForm(user)
                {
                    TopLevel = false,
                    FormBorderStyle = FormBorderStyle.None,
                    Dock = DockStyle.Fill
                };
            }
            SwapContent(productView);
            productView.Show();
            productView.ReloadData();
        }

        private void ShowCheckout()
        {
            if (user == null || !user.IsActive) return;
            Activate(btnSale);
            if (checkoutView == null || checkoutView.IsDisposed)
            {
                checkoutView = new CheckoutForm(user)
                {
                    TopLevel = false,
                    FormBorderStyle = FormBorderStyle.None,
                    Dock = DockStyle.Fill
                };
            }
            SwapContent(checkoutView);
            checkoutView.Show();
            checkoutView.ReloadData();
        }

        private void ShowAnalytics()
        {
            if (user == null || !user.CanManageInventory) return;
            Activate(btnAnalytics);
            if (analyticsView == null || analyticsView.IsDisposed)
            {
                analyticsView = new AnalyticsForm(user)
                {
                    TopLevel = false,
                    FormBorderStyle = FormBorderStyle.None,
                    Dock = DockStyle.Fill
                };
            }
            SwapContent(analyticsView);
            analyticsView.Show();
            analyticsView.ReloadData();
        }

        private void ShowUsers()
        {
            if (user == null || !user.IsAdmin) return;
            Activate(btnUsers);
            if (usersView == null || usersView.IsDisposed)
            {
                usersView = new UserAdminForm(user)
                {
                    TopLevel = false,
                    FormBorderStyle = FormBorderStyle.None,
                    Dock = DockStyle.Fill
                };
            }
            SwapContent(usersView);
            usersView.Show();
            usersView.ReloadData();
        }

        private void ShowCustomers()
        {
            if (user == null || !user.IsActive) return;
            Activate(btnCustomers);
            if (customersView == null || customersView.IsDisposed)
            {
                customersView = new CustomerForm(user)
                {
                    TopLevel = false,
                    FormBorderStyle = FormBorderStyle.None,
                    Dock = DockStyle.Fill
                };
            }
            SwapContent(customersView);
            customersView.Show();
            customersView.ReloadData();
        }

        private void ShowAccount()
        {
            Activate(btnAccount);
            SwapContent(accountView);
        }

        private void SwapContent(Control view)
        {
            content.SuspendLayout();
            content.Controls.Clear();
            content.Controls.Add(view);
            view.Dock = DockStyle.Fill;
            content.ResumeLayout();
        }

        private void LoadDashboard()
        {
            try
            {
                var stats = dashboard.Stats();
                lblSales.Text = Theme.Money(stats.TodaySales);
                lblOrders.Text = stats.TodayOrders.ToString();
                lblLow.Text = stats.LowStockCount.ToString();
                lblProducts.Text = stats.ActiveProducts.ToString();
                gridLow.DataSource = dashboard.LowStock();
                gridRecent.DataSource = new AnalyticsService(user).RecentOrders(10);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not load the dashboard.\n\n" + ex.Message, "Database error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
