using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Sales analytics: totals, daily revenue chart, best sellers and sales by category for a date range.</summary>
    public sealed class AnalyticsForm : Form
    {
        private readonly AnalyticsService service;
        private readonly DateTimePicker dtpFrom = new DateTimePicker();
        private readonly DateTimePicker dtpTo = new DateTimePicker();
        private readonly Label lblRevenue = new Label();
        private readonly Label lblOrders = new Label();
        private readonly Label lblAverage = new Label();
        private readonly Label lblChartTitle = new Label();
        private readonly BarChartPanel chart = new BarChartPanel();
        private readonly DataGridView gridTop = new DataGridView();
        private readonly DataGridView gridCategory = new DataGridView();

        public AnalyticsForm(User user)
        {
            service = new AnalyticsService(user);
            Text = "Analytics";
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            var root = new Panel { Dock = DockStyle.Fill, Padding = new Padding(28, 24, 28, 20), BackColor = Theme.Background };

            var heading = new Label { Text = "Sales Analytics", Font = Theme.Bold(20f), AutoSize = true, Dock = DockStyle.Top };

            var filter = BuildFilter();

            var cards = new TableLayoutPanel { Dock = DockStyle.Top, Height = 104, ColumnCount = 3, RowCount = 1, Padding = new Padding(0, 4, 0, 12) };
            for (int i = 0; i < 3; i++) cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
            cards.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            cards.Controls.Add(MakeCard("Revenue", lblRevenue, Theme.Rose, Color.White), 0, 0);
            cards.Controls.Add(MakeCard("Orders", lblOrders, Theme.Sage, Theme.Slate), 1, 0);
            cards.Controls.Add(MakeCard("Average order", lblAverage, Theme.Slate, Theme.Peach), 2, 0);

            lblChartTitle.Text = "Daily revenue";
            lblChartTitle.Font = Theme.Bold(12f);
            lblChartTitle.AutoSize = true;
            lblChartTitle.Dock = DockStyle.Top;
            lblChartTitle.Padding = new Padding(0, 4, 0, 6);

            chart.Dock = DockStyle.Top;
            chart.Height = 240;

            ConfigureTopGrid();
            ConfigureCategoryGrid();

            var lower = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, Padding = new Padding(0, 14, 0, 0) };
            lower.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            lower.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            lower.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            lower.Controls.Add(MakePane("Best-selling products", gridTop, new Padding(0, 0, 10, 0)), 0, 0);
            lower.Controls.Add(MakePane("Sales by category", gridCategory, new Padding(10, 0, 0, 0)), 1, 0);

            // Last added is docked first.
            root.Controls.Add(lower);
            root.Controls.Add(chart);
            root.Controls.Add(lblChartTitle);
            root.Controls.Add(cards);
            root.Controls.Add(filter);
            root.Controls.Add(heading);
            Controls.Add(root);

            dtpTo.Value = DateTime.Today;
            dtpFrom.Value = DateTime.Today.AddDays(-6);
        }

        /// <summary>Called by the main window each time the screen is shown.</summary>
        public void ReloadData()
        {
            LoadData();
        }

        // ---------------- layout helpers ----------------

        private Control BuildFilter()
        {
            var bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 52, WrapContents = false, Padding = new Padding(0, 8, 0, 0) };

            foreach (var d in new[] { dtpFrom, dtpTo })
            {
                d.Format = DateTimePickerFormat.Short;
                d.Width = 120;
                d.Margin = new Padding(0, 4, 8, 0);
            }

            bar.Controls.Add(new Label { Text = "From", AutoSize = true, ForeColor = Theme.Muted, Margin = new Padding(0, 8, 6, 0) });
            bar.Controls.Add(dtpFrom);
            bar.Controls.Add(new Label { Text = "To", AutoSize = true, ForeColor = Theme.Muted, Margin = new Padding(6, 8, 6, 0) });
            bar.Controls.Add(dtpTo);
            bar.Controls.Add(FilterButton("Show", Theme.Primary, (s, e) => LoadData(), 80));
            bar.Controls.Add(FilterButton("Today", Theme.Soft, (s, e) => SetRange(0), 80));
            bar.Controls.Add(FilterButton("7 days", Theme.Soft, (s, e) => SetRange(6), 80));
            bar.Controls.Add(FilterButton("30 days", Theme.Soft, (s, e) => SetRange(29), 84));
            bar.Controls.Add(FilterButton("This month", Theme.Soft, (s, e) => SetMonth(), 100));
            return bar;
        }

        private static Button FilterButton(string text, Action<Button> style, EventHandler click, int width)
        {
            var b = new Button { Text = text, Width = width, Height = 32, Margin = new Padding(0, 2, 8, 0) };
            style(b);
            b.Click += click;
            return b;
        }

        private static Control MakeCard(string caption, Label value, Color back, Color fore)
        {
            var card = new Panel { Dock = DockStyle.Fill, BackColor = back, Margin = new Padding(0, 0, 14, 0), Padding = new Padding(18, 12, 14, 8) };
            var cap = new Label { Text = caption, ForeColor = fore, AutoSize = true, Dock = DockStyle.Top };
            value.ForeColor = fore;
            value.Font = Theme.Bold(22f);
            value.AutoSize = false;
            value.Dock = DockStyle.Fill;
            value.TextAlign = ContentAlignment.MiddleLeft;
            value.Text = "-";
            card.Controls.Add(value);
            card.Controls.Add(cap);
            return card;
        }

        private static Control MakePane(string title, DataGridView grid, Padding padding)
        {
            var pane = new Panel { Dock = DockStyle.Fill, Padding = padding };
            pane.Controls.Add(grid);
            pane.Controls.Add(new Label { Text = title, Font = Theme.Bold(12f), AutoSize = true, Dock = DockStyle.Top, Padding = new Padding(0, 0, 0, 6) });
            return pane;
        }

        private static void ConfigureGrid(DataGridView g)
        {
            g.Dock = DockStyle.Fill;
            g.ReadOnly = true;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.RowHeadersVisible = false;
            g.AutoGenerateColumns = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Theme.StyleGrid(g);
        }

        private static DataGridViewTextBoxColumn Col(string property, string header, int width, string format, bool right)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName = property, HeaderText = header, Name = property };
            if (width > 0) c.Width = width;
            if (format != null) c.DefaultCellStyle.Format = format;
            if (right)
            {
                c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                c.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleRight;
            }
            return c;
        }

        private void ConfigureTopGrid()
        {
            ConfigureGrid(gridTop);
            gridTop.Columns.Add(Col("ProductName", "Product", 0, null, false));
            gridTop.Columns.Add(Col("QtySold", "Qty sold", 80, "N0", true));
            gridTop.Columns.Add(Col("Revenue", "Revenue", 100, Theme.MoneyFormat, true));
            gridTop.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private void ConfigureCategoryGrid()
        {
            ConfigureGrid(gridCategory);
            gridCategory.Columns.Add(Col("CategoryName", "Category", 0, null, false));
            gridCategory.Columns.Add(Col("Revenue", "Revenue", 100, Theme.MoneyFormat, true));
            gridCategory.Columns.Add(Col("Share", "Share %", 80, "0.0", true));
            gridCategory.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        // ---------------- date range ----------------

        private void SetRange(int daysBack)
        {
            dtpTo.Value = DateTime.Today;
            dtpFrom.Value = DateTime.Today.AddDays(-daysBack);
            LoadData();
        }

        private void SetMonth()
        {
            var today = DateTime.Today;
            dtpFrom.Value = new DateTime(today.Year, today.Month, 1);
            dtpTo.Value = today;
            LoadData();
        }

        // ---------------- data ----------------

        private void LoadData()
        {
            var from = dtpFrom.Value.Date;
            var to = dtpTo.Value.Date;
            try
            {
                var daily = service.Daily(from, to);
                var top = service.TopProducts(from, to, 10);
                var categories = service.ByCategory(from, to);

                decimal revenue = daily.Sum(d => d.Revenue);
                int orders = daily.Sum(d => d.OrderCount);
                lblRevenue.Text = Theme.Money(revenue);
                lblOrders.Text = orders.ToString("N0");
                lblAverage.Text = Theme.Money(orders > 0 ? revenue / orders : 0m);

                lblChartTitle.Text = from == to
                    ? "Revenue on " + from.ToString("MMM d, yyyy")
                    : "Daily revenue, " + from.ToString("MMM d") + " to " + to.ToString("MMM d, yyyy");
                chart.SetData(daily.Select(d => new KeyValuePair<string, decimal>(d.SaleDate.ToString("MMM d"), d.Revenue)));

                gridTop.DataSource = top;
                gridCategory.DataSource = categories;
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Analytics", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not load the report.\n\n" + ex.Message, "Analytics",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
