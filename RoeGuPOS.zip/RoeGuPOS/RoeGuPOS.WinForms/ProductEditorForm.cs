using System;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Add / edit dialog. Pass null to create a product, or an existing product to edit it.</summary>
    public sealed class ProductEditorForm : Form
    {
        private readonly InventoryService service;
        private readonly Product product;
        private readonly bool isNew;

        private readonly TextBox txtSku = new TextBox();
        private readonly TextBox txtBarcode = new TextBox();
        private readonly TextBox txtName = new TextBox();
        private readonly ComboBox cboCategory = new ComboBox();
        private readonly NumericUpDown numPrice = new NumericUpDown();
        private readonly NumericUpDown numCost = new NumericUpDown();
        private readonly NumericUpDown numStock = new NumericUpDown();
        private readonly NumericUpDown numReorder = new NumericUpDown();
        private readonly NumericUpDown numBulkQty = new NumericUpDown();    // 0 = no bulk price
        private readonly NumericUpDown numBulkPrice = new NumericUpDown();  // 0 = no bulk price
        private readonly CheckBox chkActive = new CheckBox();
        private readonly PictureBox picture = new PictureBox();
        private readonly Label lblNoImage = new Label();

        private byte[] newImage;          // PNG bytes chosen in this dialog (null + imageChanged = remove)
        private bool imageChanged;

        public ProductEditorForm(InventoryService service, Product existing)
        {
            this.service = service;
            isNew = existing == null;
            product = existing ?? new Product { IsActive = true, ReorderLevel = 5 };

            Text = isNew ? "Add product" : "Edit product";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            txtSku.MaxLength = 30;
            txtBarcode.MaxLength = 50;
            txtName.MaxLength = 150;
            cboCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cboCategory.DisplayMember = "Name";
            cboCategory.ValueMember = "CategoryId";
            foreach (var n in new[] { numPrice, numCost, numBulkPrice })
            {
                n.DecimalPlaces = 2;
                n.Maximum = 9999999m;
                n.ThousandsSeparator = true;
            }
            numStock.Maximum = 1000000;
            numReorder.Maximum = 1000000;
            numBulkQty.Maximum = 100000;
            chkActive.Text = "Active (available for sale)";

            int y = 16;
            AddRow("SKU *", txtSku, ref y);
            AddRow("Barcode", txtBarcode, ref y);
            AddRow("Name *", txtName, ref y);
            AddRow("Category *", cboCategory, ref y);
            AddRow("Selling price", numPrice, ref y);
            AddRow("Cost price", numCost, ref y);
            AddRow(isNew ? "Initial stock" : "Stock (use Adjust stock)", numStock, ref y);
            AddRow("Reorder level", numReorder, ref y);
            AddRow("Bulk: buy at least", numBulkQty, ref y);
            AddRow("Bulk price (each)", numBulkPrice, ref y);
            Controls.Add(new Label
            {
                Text = "Bulk price is optional. Leave both at 0 for none. Example: at least 10 and 45.00 charges 45.00 for each unit once 10 or more are bought.",
                ForeColor = Theme.Muted,
                Font = Theme.Base(8.5f),
                Location = new Point(16, y - 4),
                Size = new Size(388, 34)
            });
            y += 40;

            // Picture
            Controls.Add(new Label { Text = "Picture", AutoSize = true, Location = new Point(16, y + 4) });
            picture.Location = new Point(150, y);
            picture.Size = new Size(120, 120);
            picture.SizeMode = PictureBoxSizeMode.Zoom;
            picture.BorderStyle = BorderStyle.FixedSingle;
            picture.BackColor = Theme.Surface;
            lblNoImage.Text = "No picture";
            lblNoImage.ForeColor = Theme.Muted;
            lblNoImage.TextAlign = ContentAlignment.MiddleCenter;
            lblNoImage.Dock = DockStyle.Fill;
            picture.Controls.Add(lblNoImage);
            Controls.Add(picture);

            var btnChoose = new Button { Text = "Choose...", Location = new Point(284, y), Size = new Size(116, 32) };
            var btnRemove = new Button { Text = "Remove", Location = new Point(284, y + 38), Size = new Size(116, 32) };
            Theme.Secondary(btnChoose);
            Theme.Soft(btnRemove);
            btnChoose.Click += (s, e) => ChoosePicture();
            btnRemove.Click += (s, e) => RemovePicture();
            Controls.Add(btnChoose);
            Controls.Add(btnRemove);
            Controls.Add(new Label
            {
                Text = "JPG or PNG, up to 5 MB.\nResized automatically.",
                ForeColor = Theme.Muted,
                Font = Theme.Base(8.5f),
                Location = new Point(284, y + 78),
                Size = new Size(120, 40)
            });
            y += 134;

            chkActive.Location = new Point(150, y);
            chkActive.AutoSize = true;
            Controls.Add(chkActive);
            y += 44;

            var btnSave = new Button { Text = "Save", Location = new Point(150, y), Size = new Size(120, 36), DialogResult = DialogResult.None };
            var btnCancel = new Button { Text = "Cancel", Location = new Point(280, y), Size = new Size(120, 36), DialogResult = DialogResult.Cancel };
            Theme.Primary(btnSave);
            Theme.Soft(btnCancel);
            btnSave.Click += (s, e) => Save();
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            AcceptButton = btnSave;
            CancelButton = btnCancel;
            ClientSize = new Size(420, y + 56);

            Load += (s, e) => LoadValues();
            FormClosed += (s, e) => { if (picture.Image != null) picture.Image.Dispose(); };
        }

        private void AddRow(string label, Control input, ref int y)
        {
            Controls.Add(new Label { Text = label, AutoSize = true, Location = new Point(16, y + 4) });
            input.Location = new Point(150, y);
            input.Width = 250;
            Controls.Add(input);
            y += 40;
        }

        private void LoadValues()
        {
            try
            {
                cboCategory.DataSource = service.Categories();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not load categories.\n\n" + ex.Message, "Inventory",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult = DialogResult.Cancel;
                return;
            }

            if (isNew) return;
            txtSku.Text = product.Sku;
            txtBarcode.Text = product.Barcode;
            txtName.Text = product.Name;
            cboCategory.SelectedValue = product.CategoryId;
            numPrice.Value = product.Price;
            numCost.Value = product.Cost;
            numStock.Value = product.StockQty;
            numStock.Enabled = false; // stock changes must go through Adjust stock so they are logged
            numReorder.Value = product.ReorderLevel;
            numBulkQty.Value = product.BulkMinQty.HasValue ? product.BulkMinQty.Value : 0;
            numBulkPrice.Value = product.BulkPrice.HasValue ? product.BulkPrice.Value : 0m;
            chkActive.Checked = product.IsActive;

            try
            {
                ShowPicture(ImageHelper.FromBytes(service.GetImage(product.ProductId)));
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not load the picture.\n\n" + ex.Message, "Inventory",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void ShowPicture(Image img)
        {
            var old = picture.Image;
            picture.Image = img;
            lblNoImage.Visible = img == null;
            if (old != null) old.Dispose();
        }

        private void ChoosePicture()
        {
            using (var dlg = new OpenFileDialog())
            {
                dlg.Title = "Choose a product picture";
                dlg.Filter = "Pictures (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";
                dlg.CheckFileExists = true;
                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    var png = ImageHelper.LoadAndShrink(dlg.FileName);
                    ShowPicture(ImageHelper.FromBytes(png));
                    newImage = png;
                    imageChanged = true;
                }
                catch (InvalidOperationException ex)
                {
                    MessageBox.Show(this, ex.Message, "Picture", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Could not read that file.\n\n" + ex.Message, "Picture",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void RemovePicture()
        {
            ShowPicture(null);
            newImage = null;
            imageChanged = true;
        }

        private void Save()
        {
            if (cboCategory.SelectedValue == null)
            {
                MessageBox.Show(this, "Choose a category.", "Inventory", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            product.Sku = txtSku.Text;
            product.Barcode = txtBarcode.Text;
            product.Name = txtName.Text;
            product.CategoryId = (int)cboCategory.SelectedValue;
            product.Price = numPrice.Value;
            product.Cost = numCost.Value;
            product.ReorderLevel = (int)numReorder.Value;
            product.BulkMinQty = numBulkQty.Value > 0 ? (int?)numBulkQty.Value : null;
            product.BulkPrice = numBulkPrice.Value > 0m ? (decimal?)numBulkPrice.Value : null;
            product.IsActive = isNew ? true : chkActive.Checked;
            if (isNew) product.StockQty = (int)numStock.Value;

            product.ChangeImage = imageChanged;
            product.Image = imageChanged ? newImage : null;

            try
            {
                service.Save(product);
                DialogResult = DialogResult.OK;
            }
            catch (InvalidOperationException ex)
            {
                // Validation / duplicate SKU messages are written for the user.
                MessageBox.Show(this, ex.Message, "Inventory", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not save the product.\n\n" + ex.Message, "Inventory",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // The product object comes from the list; never leave image bytes on it.
                product.Image = null;
                product.ChangeImage = false;
            }
        }
    }
}
