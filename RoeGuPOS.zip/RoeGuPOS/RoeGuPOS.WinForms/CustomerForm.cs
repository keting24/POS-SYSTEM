using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Customer list with search, add, edit and delete.</summary>
    public sealed class CustomerForm : Form
    {
        private readonly CustomerService service;
        private readonly TextBox txtSearch = new TextBox();
        private readonly DataGridView grid = new DataGridView();
        private readonly Label lblCount = new Label();
        private readonly Timer searchTimer = new Timer();
        private List<Customer> current = new List<Customer>();

        public CustomerForm(User user)
        {
            service = new CustomerService(user);
            Text = "Customers";
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;
            BuildLayout();
        }

        private void BuildLayout()
        {
            var heading = new Label
            {
                Text = "Customers",
                Font = Theme.Bold(20f),
                AutoSize = true,
                Dock = DockStyle.Top,
                Padding = new Padding(28, 24, 0, 6)
            };

            var top = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(24, 10, 12, 6),
                WrapContents = true,
                BackColor = Theme.Background
            };

            txtSearch.Width = 260;
            txtSearch.Margin = new Padding(0, 5, 14, 0);
            txtSearch.BorderStyle = BorderStyle.FixedSingle;
            txtSearch.TextChanged += (s, e) => { searchTimer.Stop(); searchTimer.Start(); };
            searchTimer.Interval = 300;
            searchTimer.Tick += (s, e) => { searchTimer.Stop(); ReloadData(); };

            top.Controls.Add(new Label { Text = "Search:", AutoSize = true, Margin = new Padding(0, 8, 4, 0) });
            top.Controls.Add(txtSearch);
            top.Controls.Add(MakeButton("Add", Theme.Primary, (s, e) => AddCustomer()));
            top.Controls.Add(MakeButton("Edit", Theme.Secondary, (s, e) => EditSelected()));
            if (service.CanDelete) top.Controls.Add(MakeButton("Delete", Theme.Dark, (s, e) => DeleteSelected()));
            if (service.CanDelete) top.Controls.Add(MakeButton("Adjust points", Theme.Accent, (s, e) => AdjustPoints()));
            top.Controls.Add(MakeButton("Points history", Theme.Soft, (s, e) => ShowPointsHistory()));
            top.Controls.Add(MakeButton("Refresh", Theme.Soft, (s, e) => ReloadData()));

            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.MultiSelect = false;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.AutoGenerateColumns = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Theme.StyleGrid(grid);
            grid.Columns.Add(Col("FullName", "Name", 220));
            grid.Columns.Add(Col("Phone", "Phone", 150));
            grid.Columns.Add(Col("Email", "Email", 220));
            grid.Columns.Add(Col("LoyaltyPoints", "Points", 80));
            grid.Columns["LoyaltyPoints"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            grid.Columns["LoyaltyPoints"].DefaultCellStyle.Format = "N0";
            grid.Columns.Add(Col("Address", "Address", 0));
            grid.Columns["Address"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) EditSelected(); };

            lblCount.Dock = DockStyle.Bottom;
            lblCount.Height = 30;
            lblCount.ForeColor = Theme.Muted;
            lblCount.Padding = new Padding(28, 6, 0, 0);

            var host = new Panel { Dock = DockStyle.Fill, Padding = new Padding(28, 0, 28, 0), BackColor = Theme.Background };
            host.Controls.Add(grid);

            Controls.Add(host);
            Controls.Add(lblCount);
            Controls.Add(top);
            Controls.Add(heading);
        }

        private static Button MakeButton(string text, Action<Button> style, EventHandler click)
        {
            var b = new Button
            {
                Text = text,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Margin = new Padding(0, 4, 8, 0),
                Padding = new Padding(10, 0, 10, 0),
                Height = 34,
                MinimumSize = new Size(86, 34)
            };
            style(b);
            b.Click += click;
            return b;
        }

        private static DataGridViewTextBoxColumn Col(string property, string header, int width)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName = property, HeaderText = header, Name = property };
            if (width > 0) c.Width = width;
            return c;
        }

        public void ReloadData()
        {
            try
            {
                current = service.Search(txtSearch.Text);
                grid.DataSource = null;
                grid.DataSource = current;
                lblCount.Text = current.Count + " customer(s)";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not load customers.\n\n" + ex.Message, "Customers", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Customer Selected()
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Index < 0 || grid.CurrentRow.Index >= current.Count) return null;
            return current[grid.CurrentRow.Index];
        }

        private void AddCustomer()
        {
            using (var dlg = new CustomerEditorForm(service, null))
                if (dlg.ShowDialog(this) == DialogResult.OK) ReloadData();
        }

        private void EditSelected()
        {
            var c = Selected();
            if (c == null) { Info("Select a customer first."); return; }
            using (var dlg = new CustomerEditorForm(service, c))
                if (dlg.ShowDialog(this) == DialogResult.OK) ReloadData();
        }

        private void DeleteSelected()
        {
            var c = Selected();
            if (c == null) { Info("Select a customer first."); return; }
            if (MessageBox.Show(this, "Delete \"" + c.FullName + "\"?", "Confirm delete",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
            try
            {
                service.Delete(c.CustomerId);
                ReloadData();
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Customers", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not delete the customer.\n\n" + ex.Message, "Customers", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AdjustPoints()
        {
            var c = Selected();
            if (c == null) { Info("Select a customer first."); return; }
            using (var dlg = new PointsAdjustForm(service, c))
                if (dlg.ShowDialog(this) == DialogResult.OK) ReloadData();
        }

        private void ShowPointsHistory()
        {
            var c = Selected();
            if (c == null) { Info("Select a customer first."); return; }
            using (var dlg = new PointsHistoryForm(service, c))
                dlg.ShowDialog(this);
        }

        private void Info(string text)
        {
            MessageBox.Show(this, text, "Customers", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
