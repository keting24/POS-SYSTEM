using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>User and role administration (Admin only).</summary>
    public sealed class UserAdminForm : Form
    {
        private readonly UserAdminService service;
        private readonly User signedIn;
        private readonly DataGridView grid = new DataGridView();
        private readonly Label lblCount = new Label();
        private readonly TextBox txtSearch = new TextBox();
        private readonly Timer searchTimer = new Timer();
        private List<ManagedUser> current = new List<ManagedUser>();

        public UserAdminForm(User user)
        {
            signedIn = user;
            service = new UserAdminService(user);
            Text = "Users";
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;
            BuildLayout();
        }

        private void BuildLayout()
        {
            var heading = new Label
            {
                Text = "Users",
                Font = Theme.Bold(20f),
                AutoSize = true,
                Dock = DockStyle.Top,
                Padding = new Padding(28, 24, 0, 6)
            };

            var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 56, Padding = new Padding(24, 10, 12, 0), WrapContents = false, BackColor = Theme.Background };
            txtSearch.Width = 230;
            txtSearch.Margin = new Padding(0, 9, 14, 0);
            txtSearch.BorderStyle = BorderStyle.FixedSingle;
            txtSearch.TextChanged += (s, e) => { searchTimer.Stop(); searchTimer.Start(); };
            searchTimer.Interval = 300;
            searchTimer.Tick += (s, e) => { searchTimer.Stop(); ReloadData(); };
            top.Controls.Add(new Label { Text = "Search (name, username or role):", AutoSize = true, Margin = new Padding(0, 12, 6, 0) });
            top.Controls.Add(txtSearch);
            top.Controls.Add(MakeButton("Add user", (s, e) => AddUser(), Theme.Primary));
            top.Controls.Add(MakeButton("Edit", (s, e) => EditSelected(), Theme.Secondary));
            top.Controls.Add(MakeButton("Reset password", (s, e) => ResetSelected(), Theme.Accent));
            top.Controls.Add(MakeButton("Refresh", (s, e) => ReloadData(), Theme.Soft));

            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.MultiSelect = false;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.AutoGenerateColumns = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Theme.StyleGrid(grid);
            grid.Columns.Add(Col("Username", "Username", 150));
            grid.Columns.Add(Col("FullName", "Full name", 0));
            grid.Columns.Add(Col("RoleName", "Role", 110));
            grid.Columns.Add(new DataGridViewCheckBoxColumn { DataPropertyName = "IsActive", HeaderText = "Active", Name = "IsActive", Width = 70 });
            grid.Columns.Add(Col("LastLoginAt", "Last login", 160));
            grid.Columns["LastLoginAt"].DefaultCellStyle.Format = "g";
            grid.Columns["LastLoginAt"].DefaultCellStyle.NullValue = "Never";
            grid.Columns["FullName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) EditSelected(); };
            grid.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0 || e.RowIndex >= current.Count) return;
                if (!current[e.RowIndex].IsActive) grid.Rows[e.RowIndex].DefaultCellStyle.ForeColor = Color.Gray;
            };

            lblCount.Dock = DockStyle.Bottom;
            lblCount.Height = 30;
            lblCount.ForeColor = Theme.Muted;
            lblCount.Padding = new Padding(28, 6, 0, 0);

            var host = new Panel { Dock = DockStyle.Fill, Padding = new Padding(28, 0, 28, 0), BackColor = Theme.Background };
            host.Controls.Add(grid);

            Controls.Add(host);
            Controls.Add(lblCount);
            Controls.Add(top);
            Controls.Add(heading);
        }

        private static Button MakeButton(string text, EventHandler onClick, Action<Button> style)
        {
            var b = new Button
            {
                Text = text,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Margin = new Padding(0, 4, 8, 0),
                Padding = new Padding(10, 0, 10, 0),
                Height = 34,
                MinimumSize = new Size(86, 34)
            };
            style(b);
            b.Click += onClick;
            return b;
        }

        private static DataGridViewTextBoxColumn Col(string property, string header, int width)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName = property, HeaderText = header, Name = property };
            if (width > 0) c.Width = width;
            return c;
        }

        public void ReloadData()
        {
            try
            {
                current = service.List(txtSearch.Text);
                grid.DataSource = null;
                grid.DataSource = current;
                lblCount.Text = current.Count + " user(s)";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not load users.\n\n" + ex.Message, "Users", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private ManagedUser Selected()
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Index < 0 || grid.CurrentRow.Index >= current.Count) return null;
            return current[grid.CurrentRow.Index];
        }

        private void AddUser()
        {
            using (var dlg = new UserEditorForm(service, UserEditorMode.Create, null, false))
                if (dlg.ShowDialog(this) == DialogResult.OK) ReloadData();
        }

        private void EditSelected()
        {
            var u = Selected();
            if (u == null) { Info("Select a user first."); return; }
            using (var dlg = new UserEditorForm(service, UserEditorMode.Edit, u, u.UserId == signedIn.UserId))
                if (dlg.ShowDialog(this) == DialogResult.OK) ReloadData();
        }

        private void ResetSelected()
        {
            var u = Selected();
            if (u == null) { Info("Select a user first."); return; }
            using (var dlg = new UserEditorForm(service, UserEditorMode.ResetPassword, u, false))
                if (dlg.ShowDialog(this) == DialogResult.OK)
                    Info("The password for " + u.Username + " was changed.");
        }

        private void Info(string text)
        {
            MessageBox.Show(this, text, "Users", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
