using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;
using RoeGuPOS.Domain;

namespace RoeGuPOS.WinForms
{
    /// <summary>Builds a plain-text 80mm receipt and shows it in a print preview (which has a Print button).</summary>
    internal static class ReceiptPrinter
    {
        private const int Width = 38; // characters per line in Courier New 8pt on 80mm paper

        public static void ShowPreview(IWin32Window owner, Order order)
        {
            try
            {
                var lines = Build(order);
                var doc = new PrintDocument { DocumentName = order.OrderNumber };
                int height = Math.Max(500, lines.Count * 15 + 80); // hundredths of an inch
                doc.DefaultPageSettings.PaperSize = new PaperSize("Receipt80", 315, height);
                doc.DefaultPageSettings.Margins = new Margins(10, 10, 10, 10);

                doc.PrintPage += (s, e) =>
                {
                    using (var font = new Font("Courier New", 8f))
                    {
                        float y = e.MarginBounds.Top;
                        float step = font.GetHeight(e.Graphics);
                        foreach (var line in lines)
                        {
                            e.Graphics.DrawString(line, font, Brushes.Black, e.MarginBounds.Left, y);
                            y += step;
                        }
                    }
                    e.HasMorePages = false;
                };

                using (var preview = new PrintPreviewDialog { Document = doc, Width = 520, Height = 760 })
                {
                    preview.Text = "Receipt " + order.OrderNumber;
                    preview.ShowDialog(owner);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(owner,
                    "The receipt could not be opened. Check that a printer (a PDF printer is fine) is installed.\n\n" + ex.Message,
                    "Receipt", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private static List<string> Build(Order o)
        {
            var rule = new string('-', Width);
            var lines = new List<string>();

            // Header: business details come from App.config (ReceiptBusinessName, ReceiptAddress, ReceiptPhone).
            lines.Add(Center(Setting("ReceiptBusinessName", "ENTERPRISE POS").ToUpperInvariant()));
            var address = Setting("ReceiptAddress", "123 Main Street, City");
            var phone = Setting("ReceiptPhone", "Tel: +1 555 0100");
            if (address.Length > 0) lines.Add(Center(address));
            if (phone.Length > 0) lines.Add(Center(phone));
            lines.Add(rule);

            lines.Add("Order: " + o.OrderNumber);
            lines.Add("Date : " + o.OrderDate.ToString("yyyy-MM-dd HH:mm"));
            lines.Add("Cashier: " + o.CashierName);
            if (!string.IsNullOrEmpty(o.CustomerName))
                lines.Add("Customer: " + Cut(o.CustomerName, Width - 10));
            lines.Add(rule);

            // Items: product on the left, Qty and Amount in fixed columns on the right.
            const int qtyW = 4, amountW = 12, nameW = Width - qtyW - amountW;
            lines.Add("Product".PadRight(nameW) + "Qty".PadLeft(qtyW) + "Amount".PadLeft(amountW));
            foreach (var l in o.Lines)
            {
                var name = l.Name ?? string.Empty;
                var first = Cut(name, nameW - 1);
                lines.Add(first.PadRight(nameW) + l.Quantity.ToString().PadLeft(qtyW) + Money(l.ListTotal).PadLeft(amountW));
                // A long name continues on the next lines so it never overlaps the numbers.
                for (int pos = first.Length; pos < name.Length; pos += nameW - 1)
                    lines.Add("  " + Cut(name.Substring(pos), nameW - 3));
            }
            lines.Add(rule);

            lines.Add(Row("Subtotal", Money(o.Subtotal)));
            lines.Add(Row("Tax", Money(o.TaxAmount)));
            lines.Add(Row("Discount", Money(o.DiscountAmount)));
            lines.Add(Row("TOTAL", Money(o.Total)));
            lines.Add(rule);

            lines.Add("Payment: " + (o.PaymentMethod ?? string.Empty).ToUpperInvariant());
            lines.Add(Row("Tendered:", Money(o.AmountPaid)));
            lines.Add(Row("Change:", Money(o.ChangeDue)));

            if (!string.IsNullOrEmpty(o.CustomerName))
            {
                lines.Add(rule);
                if (o.PointsRedeemed > 0) lines.Add(Row("Points used", "-" + o.PointsRedeemed));
                lines.Add(Row("Points earned", "+" + o.PointsEarned));
                lines.Add(Row("Points balance", o.CustomerPoints.ToString()));
            }

            lines.Add(string.Empty);
            lines.Add(Center("Thank you for your purchase!"));
            var policy = Setting("ReceiptReturnPolicy", string.Empty);
            if (policy.Length > 0) { lines.Add(string.Empty); lines.Add(Center(policy)); }
            return lines;
        }

        /// <summary>Amount with the currency symbol (App.config ReceiptCurrency, else CurrencySymbol, default the peso sign).</summary>
        private static string Money(decimal value)
        {
            // ReceiptCurrency overrides the app-wide CurrencySymbol (use "PHP " if the printer cannot draw the peso sign).
            var symbol = ConfigurationManager.AppSettings["ReceiptCurrency"];
            return (string.IsNullOrWhiteSpace(symbol) ? Theme.CurrencySymbol : symbol.Trim()) + value.ToString("N2");
        }

        private static string Setting(string key, string fallback)
        {
            var v = ConfigurationManager.AppSettings[key];
            return v == null ? fallback : v.Trim();
        }

        private static string Cut(string s, int max)
        {
            s = s ?? string.Empty;
            return s.Length <= max ? s : s.Substring(0, max);
        }

        private static string Center(string s)
        {
            s = Cut(s, Width);
            return new string(' ', (Width - s.Length) / 2) + s;
        }

        private static string Row(string left, string right)
        {
            right = Cut(right, Width);
            left = Cut(left, Math.Max(0, Width - right.Length - 1));
            return left.PadRight(Width - right.Length) + right;
        }
    }
}
