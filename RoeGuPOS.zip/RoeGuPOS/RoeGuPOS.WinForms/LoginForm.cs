using System;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Module 1: database-driven login. Built in code so no designer file is needed.</summary>
    public sealed class LoginForm : Form
    {
        private readonly AuthService auth = new AuthService();
        private readonly TextBox txtUsername = new TextBox();
        private readonly TextBox txtPassword = new TextBox();
        private readonly Button btnLogin = new Button();
        private readonly Label lblError = new Label();
        private int failedAttempts;

        public LoginForm()
        {
            Text = "RoeGuPOS - Login";
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(660, 400);
            Font = Theme.Base(10f);
            BackColor = Theme.Background;

            // Left brand panel
            var brand = new Panel { Dock = DockStyle.Left, Width = 270, BackColor = Theme.Slate };
            brand.Controls.Add(new Label
            {
                Text = "RoeGuPOS",
                Font = Theme.Bold(24f),
                ForeColor = Theme.Peach,
                AutoSize = true,
                Location = new Point(28, 130)
            });
            brand.Controls.Add(new Label
            {
                Text = "Point of Sale &\nInventory Management",
                Font = Theme.Base(11f),
                ForeColor = Theme.Sage,
                AutoSize = true,
                Location = new Point(31, 180)
            });
            brand.Controls.Add(new Panel { Dock = DockStyle.Bottom, Height = 8, BackColor = Theme.Rose });

            // Right form
            var title = new Label
            {
                Text = "Welcome back",
                Font = Theme.Bold(18f),
                ForeColor = Theme.Slate,
                AutoSize = true,
                Location = new Point(310, 40)
            };
            var subtitle = new Label
            {
                Text = "Sign in to continue",
                ForeColor = Theme.Muted,
                AutoSize = true,
                Location = new Point(313, 80)
            };

            var lblUser = new Label { Text = "Username", ForeColor = Theme.Slate, AutoSize = true, Location = new Point(313, 122) };
            txtUsername.Location = new Point(313, 146);
            txtUsername.Width = 310;
            txtUsername.MaxLength = 50;
            txtUsername.BorderStyle = BorderStyle.FixedSingle;

            var lblPass = new Label { Text = "Password", ForeColor = Theme.Slate, AutoSize = true, Location = new Point(313, 190) };
            txtPassword.Location = new Point(313, 214);
            txtPassword.Width = 310;
            txtPassword.UseSystemPasswordChar = true;
            txtPassword.MaxLength = 100;
            txtPassword.BorderStyle = BorderStyle.FixedSingle;

            lblError.ForeColor = Theme.Rose;
            lblError.AutoSize = false;
            lblError.Location = new Point(313, 252);
            lblError.Size = new Size(310, 22);

            btnLogin.Text = "Login";
            btnLogin.Location = new Point(313, 284);
            btnLogin.Size = new Size(310, 42);
            btnLogin.Font = Theme.Bold(11f);
            Theme.Primary(btnLogin);
            btnLogin.Click += (s, e) => DoLogin();

            Controls.Add(brand);
            Controls.AddRange(new Control[] { title, subtitle, lblUser, txtUsername, lblPass, txtPassword, lblError, btnLogin });
            AcceptButton = btnLogin;
            Shown += (s, e) => txtUsername.Focus();
        }

        private void DoLogin()
        {
            lblError.Text = string.Empty;
            if (txtUsername.Text.Trim().Length == 0 || txtPassword.Text.Length == 0)
            {
                lblError.Text = "Enter your username and password.";
                return;
            }

            try
            {
                UseWaitCursor = true;
                var user = auth.Login(txtUsername.Text, txtPassword.Text);
                if (user == null)
                {
                    failedAttempts++;
                    txtPassword.Clear();
                    txtPassword.Focus();
                    lblError.Text = "Invalid username or password.";
                    if (failedAttempts >= 5)
                    {
                        MessageBox.Show(this, "Too many failed attempts. The application will close.",
                            "Login", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        DialogResult = DialogResult.Cancel;
                    }
                    return;
                }

                AppSession.CurrentUser = user;
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this,
                    "Could not reach the database. Check the connection string in App.config and that SQL Server is running.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                UseWaitCursor = false;
            }
        }
    }
}
