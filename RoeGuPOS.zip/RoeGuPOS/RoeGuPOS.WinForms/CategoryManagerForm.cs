using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Dialog to add, rename and delete product categories.</summary>
    public sealed class CategoryManagerForm : Form
    {
        private readonly CategoryService service;
        private readonly DataGridView grid = new DataGridView();
        private List<CategoryInfo> current = new List<CategoryInfo>();

        public CategoryManagerForm(User user)
        {
            service = new CategoryService(user);
            Text = "Categories";
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            MinimizeBox = false;
            ClientSize = new Size(660, 440);
            MinimumSize = new Size(560, 360);
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            var buttons = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 56, Padding = new Padding(16, 10, 8, 0), WrapContents = false };
            buttons.Controls.Add(MakeButton("Add", Theme.Primary, (s, e) => Add()));
            buttons.Controls.Add(MakeButton("Rename / edit", Theme.Secondary, (s, e) => EditSelected()));
            buttons.Controls.Add(MakeButton("Delete", Theme.Dark, (s, e) => DeleteSelected()));
            buttons.Controls.Add(MakeButton("Close", Theme.Soft, (s, e) => Close()));

            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.MultiSelect = false;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.AutoGenerateColumns = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Theme.StyleGrid(grid);
            grid.Columns.Add(Col("Name", "Category", 190));
            grid.Columns.Add(Col("Description", "Description", 0));
            grid.Columns.Add(Col("ProductCount", "Products", 80));
            grid.Columns["Description"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) EditSelected(); };

            var host = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16, 0, 16, 16) };
            host.Controls.Add(grid);
            Controls.Add(host);
            Controls.Add(buttons);

            Load += (s, e) => ReloadData();
        }

        private static Button MakeButton(string text, Action<Button> style, EventHandler click)
        {
            var b = new Button { Text = text, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, MinimumSize = new Size(86, 34), Padding = new Padding(10, 0, 10, 0), Margin = new Padding(0, 0, 8, 0) };
            style(b);
            b.Click += click;
            return b;
        }

        private static DataGridViewTextBoxColumn Col(string property, string header, int width)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName = property, HeaderText = header, Name = property };
            if (width > 0) c.Width = width;
            return c;
        }

        private void ReloadData()
        {
            try
            {
                current = service.List();
                grid.DataSource = null;
                grid.DataSource = current;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not load categories.\n\n" + ex.Message, "Categories", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private CategoryInfo Selected()
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Index < 0 || grid.CurrentRow.Index >= current.Count) return null;
            return current[grid.CurrentRow.Index];
        }

        private void Add()
        {
            using (var dlg = new CategoryEditorForm(service, null))
                if (dlg.ShowDialog(this) == DialogResult.OK) ReloadData();
        }

        private void EditSelected()
        {
            var c = Selected();
            if (c == null) { MessageBox.Show(this, "Select a category first.", "Categories", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            using (var dlg = new CategoryEditorForm(service, c))
                if (dlg.ShowDialog(this) == DialogResult.OK) ReloadData();
        }

        private void DeleteSelected()
        {
            var c = Selected();
            if (c == null) { MessageBox.Show(this, "Select a category first.", "Categories", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
            if (MessageBox.Show(this, "Delete the category \"" + c.Name + "\"?", "Confirm delete",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;
            try
            {
                service.Delete(c.CategoryId);
                ReloadData();
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Categories", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not delete the category.\n\n" + ex.Message, "Categories", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    /// <summary>Small dialog for one category's name and description.</summary>
    public sealed class CategoryEditorForm : Form
    {
        private readonly CategoryService service;
        private readonly CategoryInfo category;
        private readonly TextBox txtName = new TextBox();
        private readonly TextBox txtDescription = new TextBox();

        public CategoryEditorForm(CategoryService service, CategoryInfo existing)
        {
            this.service = service;
            category = existing ?? new CategoryInfo();

            Text = existing == null ? "Add category" : "Edit category";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(420, 190);
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            Controls.Add(new Label { Text = "Name *", AutoSize = true, Location = new Point(16, 22) });
            txtName.Location = new Point(120, 18);
            txtName.Width = 280;
            txtName.MaxLength = 100;
            txtName.Text = category.Name;
            Controls.Add(txtName);

            Controls.Add(new Label { Text = "Description", AutoSize = true, Location = new Point(16, 62) });
            txtDescription.Location = new Point(120, 58);
            txtDescription.Width = 280;
            txtDescription.MaxLength = 200;
            txtDescription.Text = category.Description;
            Controls.Add(txtDescription);

            var btnSave = new Button { Text = "Save", Location = new Point(120, 120), Size = new Size(130, 36) };
            var btnCancel = new Button { Text = "Cancel", Location = new Point(270, 120), Size = new Size(130, 36), DialogResult = DialogResult.Cancel };
            Theme.Primary(btnSave);
            Theme.Soft(btnCancel);
            btnSave.Click += (s, e) => Save();
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            AcceptButton = btnSave;
            CancelButton = btnCancel;
        }

        private void Save()
        {
            category.Name = txtName.Text;
            category.Description = txtDescription.Text;
            try
            {
                service.Save(category);
                DialogResult = DialogResult.OK;
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Categories", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not save the category.\n\n" + ex.Message, "Categories", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
