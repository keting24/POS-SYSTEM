using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>
    /// New Sale: scan or search products, build the cart, take payment, print the receipt.
    /// A USB barcode scanner just types the code and presses Enter in the scan box.
    /// </summary>
    public sealed class CheckoutForm : Form
    {
        private readonly SalesService sales;
        private readonly User user;
        private int? customerId;
        private readonly Button btnCustomer = new Button();
        private int customerPoints;                       // the chosen customer's balance when picked
        private readonly NumericUpDown numPoints = new NumericUpDown();
        private readonly Label lblPointsInfo = new Label();
        private readonly BindingList<CartLine> cart = new BindingList<CartLine>();
        private List<Product> found = new List<Product>();
        private bool updating;

        private readonly TextBox txtScan = new TextBox();
        private readonly Label lblStatus = new Label();
        private readonly DataGridView gridProducts = new DataGridView();
        private readonly DataGridView gridCart = new DataGridView();
        private readonly NumericUpDown numPaid = new NumericUpDown();
        private readonly ComboBox cboPayment = new ComboBox();
        private readonly Label lblSubtotal = new Label();
        private readonly Label lblTax = new Label();
        private readonly Label lblSavings = new Label();
        private readonly Label lblTotal = new Label();
        private readonly Label lblChange = new Label();
        private readonly Button btnCheckout = new Button();
        private readonly Timer searchTimer = new Timer();

        public CheckoutForm(User user)
        {
            this.user = user;
            sales = new SalesService(user);
            Text = "New Sale";
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            var left = BuildLeft();
            var right = BuildRight();
            Controls.Add(left);   // Fill goes in first,
            Controls.Add(right);  // the docked-right panel after it.

            searchTimer.Interval = 250;
            searchTimer.Tick += (s, e) => { searchTimer.Stop(); RunSearch(); };

            Load += (s, e) => { RunSearch(); RefreshTotals(); txtScan.Focus(); };
        }

        /// <summary>Called by the main window each time the screen is shown.</summary>
        public void ReloadData()
        {
            RunSearch();
            txtScan.Focus();
        }

        // ---------------- layout ----------------

        private Control BuildLeft()
        {
            var pnl = new Panel { Dock = DockStyle.Fill, Padding = new Padding(28, 24, 16, 20), BackColor = Theme.Background };

            var heading = new Label { Text = "New Sale", Font = Theme.Bold(20f), AutoSize = true, Dock = DockStyle.Top };

            var scanBox = new Panel { Dock = DockStyle.Top, Height = 96 };
            scanBox.Controls.Add(new Label { Text = "Scan barcode or type SKU / product name, then press Enter", ForeColor = Theme.Muted, AutoSize = true, Location = new Point(0, 8) });
            txtScan.Location = new Point(0, 32);
            txtScan.Width = 420;
            txtScan.Font = Theme.Base(14f);
            txtScan.BorderStyle = BorderStyle.FixedSingle;
            txtScan.MaxLength = 100;
            txtScan.TextChanged += (s, e) => { searchTimer.Stop(); searchTimer.Start(); };
            txtScan.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; SubmitScan(); }
                else if (e.KeyCode == Keys.Down && gridProducts.Rows.Count > 0) { gridProducts.Focus(); }
            };
            lblStatus.Location = new Point(0, 70);
            lblStatus.AutoSize = true;
            lblStatus.ForeColor = Theme.Muted;
            scanBox.Controls.Add(txtScan);
            scanBox.Controls.Add(lblStatus);

            gridProducts.Dock = DockStyle.Fill;
            gridProducts.ReadOnly = true;
            gridProducts.MultiSelect = false;
            gridProducts.AllowUserToAddRows = false;
            gridProducts.AllowUserToDeleteRows = false;
            gridProducts.RowHeadersVisible = false;
            gridProducts.AutoGenerateColumns = false;
            gridProducts.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Theme.StyleGrid(gridProducts);
            gridProducts.Columns.Add(Col("Sku", "SKU", 110, null));
            gridProducts.Columns.Add(Col("Name", "Product", 0, null));
            gridProducts.Columns.Add(Col("Price", "Price", 90, Theme.MoneyFormat));
            gridProducts.Columns.Add(Col("BulkText", "Bulk price", 100, null));
            gridProducts.Columns.Add(Col("StockQty", "In stock", 80, null));
            gridProducts.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            gridProducts.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) AddSelectedProduct(); };
            gridProducts.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; AddSelectedProduct(); }
            };
            gridProducts.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0 || e.RowIndex >= found.Count) return;
                if (found[e.RowIndex].StockQty <= 0) gridProducts.Rows[e.RowIndex].DefaultCellStyle.ForeColor = Color.Gray;
            };

            // Last added is docked first.
            pnl.Controls.Add(gridProducts);
            pnl.Controls.Add(scanBox);
            pnl.Controls.Add(heading);
            return pnl;
        }

        private Control BuildRight()
        {
            var pnl = new Panel { Dock = DockStyle.Right, Width = 520, Padding = new Padding(18, 24, 24, 18), BackColor = Theme.Surface };

            var title = new Label { Text = "Cart", Font = Theme.Bold(14f), AutoSize = true, Dock = DockStyle.Top, Padding = new Padding(0, 0, 0, 8) };

            gridCart.Dock = DockStyle.Fill;
            gridCart.ReadOnly = true;
            gridCart.MultiSelect = false;
            gridCart.AllowUserToAddRows = false;
            gridCart.AllowUserToDeleteRows = false;
            gridCart.RowHeadersVisible = false;
            gridCart.AutoGenerateColumns = false;
            gridCart.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Theme.StyleGrid(gridCart);
            gridCart.Columns.Add(Col("Name", "Item", 0, null));
            gridCart.Columns.Add(Col("Quantity", "Qty", 55, null));
            gridCart.Columns.Add(Col("UnitPrice", "Price", 80, Theme.MoneyFormat));
            gridCart.Columns.Add(Col("LineTotal", "Total", 90, Theme.MoneyFormat));
            gridCart.Columns.Add(Col("PriceNote", "Note", 120, null));
            gridCart.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            gridCart.DataSource = cart;

            var cartButtons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 46, Padding = new Padding(0, 8, 0, 0), WrapContents = false };
            cartButtons.Controls.Add(SmallButton("+", Theme.Secondary, (s, e) => ChangeQty(+1), 44));
            cartButtons.Controls.Add(SmallButton("-", Theme.Secondary, (s, e) => ChangeQty(-1), 44));
            cartButtons.Controls.Add(SmallButton("Remove", Theme.Accent, (s, e) => RemoveSelected(), 90));
            cartButtons.Controls.Add(SmallButton("Clear cart", Theme.Dark, (s, e) => ClearCart(), 100));

            var pay = new Panel { Dock = DockStyle.Bottom, Height = 9 * 30 + 62 };

            var tlp = new TableLayoutPanel { Dock = DockStyle.Top, Height = 9 * 30, ColumnCount = 2, RowCount = 9 };
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38f));
            tlp.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 62f));
            for (int i = 0; i < 9; i++) tlp.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));

            // "Use points": a small number box with a live note (value of the points, points this sale earns).
            numPoints.Maximum = 0;
            numPoints.Dock = DockStyle.Left;
            numPoints.Width = 84;
            numPoints.ValueChanged += (s, e) => RefreshTotals();
            lblPointsInfo.Dock = DockStyle.Fill;
            lblPointsInfo.TextAlign = ContentAlignment.MiddleLeft;
            lblPointsInfo.Font = Theme.Base(8.5f);
            lblPointsInfo.ForeColor = Theme.Muted;
            lblPointsInfo.Padding = new Padding(8, 0, 0, 0);
            var pointsPanel = new Panel { Dock = DockStyle.Fill, Margin = new Padding(0, 2, 0, 2) };
            pointsPanel.Controls.Add(lblPointsInfo);   // Fill first,
            pointsPanel.Controls.Add(numPoints);       // then the left-docked box.

            btnCustomer.Text = "Walk-in customer (change)";
            btnCustomer.Dock = DockStyle.Fill;
            btnCustomer.Margin = new Padding(0, 2, 0, 2);
            Theme.Soft(btnCustomer);
            btnCustomer.Click += (s, e) => PickCustomer();

            cboPayment.DropDownStyle = ComboBoxStyle.DropDownList;
            cboPayment.Items.AddRange(SalesService.PaymentMethods);
            cboPayment.SelectedIndex = 0;
            cboPayment.Dock = DockStyle.Fill;
            cboPayment.SelectedIndexChanged += (s, e) => RefreshTotals();

            numPaid.DecimalPlaces = 2;
            numPaid.Maximum = 99999999m;
            numPaid.ThousandsSeparator = true;
            numPaid.Dock = DockStyle.Fill;
            numPaid.ValueChanged += (s, e) => RefreshTotals();
            numPaid.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; DoCheckout(); }
            };

            lblTotal.Font = Theme.Bold(18f);
            lblTotal.ForeColor = Theme.Rose;
            lblChange.Font = Theme.Bold(12f);

            AddRow(tlp, 0, "Customer", btnCustomer);
            AddRow(tlp, 1, "Subtotal", lblSubtotal);
            AddRow(tlp, 2, "Discount", lblSavings);
            AddRow(tlp, 3, "Use points", pointsPanel);
            AddRow(tlp, 4, "Tax", lblTax);
            AddRow(tlp, 5, "Total", lblTotal);
            AddRow(tlp, 6, "Payment", cboPayment);
            AddRow(tlp, 7, "Amount paid", numPaid);
            AddRow(tlp, 8, "Change", lblChange);

            btnCheckout.Text = "Complete sale";
            btnCheckout.Dock = DockStyle.Bottom;
            btnCheckout.Height = 52;
            btnCheckout.Font = Theme.Bold(12f);
            Theme.Primary(btnCheckout);
            btnCheckout.Click += (s, e) => DoCheckout();

            pay.Controls.Add(tlp);
            pay.Controls.Add(btnCheckout);

            pnl.Controls.Add(gridCart);
            pnl.Controls.Add(cartButtons);
            pnl.Controls.Add(pay);
            pnl.Controls.Add(title);
            return pnl;
        }

        private static void AddRow(TableLayoutPanel t, int row, string caption, Control value)
        {
            t.Controls.Add(new Label { Text = caption, ForeColor = Theme.Muted, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 0, row);
            var label = value as Label;
            if (label != null) { label.Dock = DockStyle.Fill; label.TextAlign = ContentAlignment.MiddleRight; }
            t.Controls.Add(value, 1, row);
        }

        private static Button SmallButton(string text, Action<Button> style, EventHandler click, int width)
        {
            var b = new Button { Text = text, Width = width, Height = 34, Margin = new Padding(0, 0, 8, 0) };
            style(b);
            b.Click += click;
            return b;
        }

        private static DataGridViewTextBoxColumn Col(string property, string header, int width, string format)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName = property, HeaderText = header, Name = property };
            if (width > 0) c.Width = width;
            if (format != null) c.DefaultCellStyle.Format = format;
            return c;
        }

        // ---------------- product search / scan ----------------

        private void RunSearch()
        {
            try
            {
                found = sales.Search(txtScan.Text);
                gridProducts.DataSource = null;
                gridProducts.DataSource = found;
            }
            catch (Exception ex)
            {
                SetStatus("Could not load products: " + ex.Message, true);
            }
        }

        private void SubmitScan()
        {
            var code = txtScan.Text.Trim();
            if (code.Length == 0) return;

            try
            {
                var product = sales.FindByCode(code);
                if (product == null)
                {
                    RunSearch();
                    if (found.Count == 1) product = found[0];
                }

                if (product == null)
                {
                    SetStatus(found.Count == 0 ? "No product matches \"" + code + "\"." : "Pick a product from the list below.", true);
                    txtScan.SelectAll();
                    return;
                }

                AddToCart(product);
                txtScan.Clear();
                txtScan.Focus();
            }
            catch (Exception ex)
            {
                SetStatus(ex.Message, true);
            }
        }

        private void AddSelectedProduct()
        {
            if (gridProducts.CurrentRow == null) return;
            var index = gridProducts.CurrentRow.Index;
            if (index < 0 || index >= found.Count) return;
            AddToCart(found[index]);
            txtScan.Focus();
        }

        // ---------------- cart ----------------

        private void AddToCart(Product p)
        {
            if (p.StockQty <= 0) { SetStatus(p.Name + " is out of stock.", true); return; }

            var line = cart.FirstOrDefault(l => l.ProductId == p.ProductId);
            if (line == null)
            {
                cart.Add(new CartLine
                {
                    ProductId = p.ProductId,
                    Sku = p.Sku,
                    Name = p.Name,
                    RegularPrice = p.Price,
                    BulkMinQty = p.BulkMinQty,
                    BulkPrice = p.BulkPrice,
                    BulkAllowed = customerId.HasValue,
                    MemberDiscountPercent = sales.MemberDiscountPercent,
                    Quantity = 1,
                    StockQty = p.StockQty
                });
            }
            else if (line.Quantity >= line.StockQty)
            {
                SetStatus("Only " + line.StockQty + " of " + p.Name + " in stock.", true);
                return;
            }
            else
            {
                line.Quantity++;
            }

            SetStatus("Added " + p.Name + ".", false);
            RefreshCart();
        }

        private CartLine SelectedLine()
        {
            return gridCart.CurrentRow == null ? null : gridCart.CurrentRow.DataBoundItem as CartLine;
        }

        private void ChangeQty(int delta)
        {
            var line = SelectedLine();
            if (line == null) return;
            int q = line.Quantity + delta;
            if (q > line.StockQty) { SetStatus("Only " + line.StockQty + " of " + line.Name + " in stock.", true); return; }
            if (q <= 0) { cart.Remove(line); }
            else { line.Quantity = q; }
            RefreshCart();
        }

        private void RemoveSelected()
        {
            var line = SelectedLine();
            if (line == null) return;
            cart.Remove(line);
            RefreshCart();
        }

        private void ClearCart()
        {
            if (cart.Count == 0) return;
            var answer = MessageBox.Show(this, "Remove all items from the cart?", "Clear cart",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (answer != DialogResult.Yes) return;
            cart.Clear();
            RefreshCart();
        }

        private void RefreshCart()
        {
            cart.ResetBindings();
            RefreshTotals();
        }

        // ---------------- totals ----------------

        private void RefreshTotals()
        {
            if (updating) return;
            updating = true;
            try
            {
                decimal subtotal = cart.Sum(l => l.LineTotal);
                decimal pointValue = sales.PointValue;

                // Customer prices (bulk and customer discount) are already inside the line totals. Loyalty points lower the price further,
                // but never below zero.
                int maxPoints = customerId.HasValue
                    ? SalesService.MaxRedeemable(customerPoints, subtotal, pointValue)
                    : 0;
                numPoints.Maximum = maxPoints;
                numPoints.Enabled = maxPoints > 0;
                decimal pointsDiscount = numPoints.Value * pointValue;

                var t = SalesService.Calculate(cart, pointsDiscount, sales.TaxRate);

                if (!customerId.HasValue)
                {
                    lblPointsInfo.Text = "Choose a customer to earn or use points";
                }
                else
                {
                    int earned = SalesService.PointsEarned(subtotal - pointsDiscount, sales.EarnRate);
                    lblPointsInfo.Text = (pointsDiscount > 0m ? "-" + Theme.Money(pointsDiscount) + "   " : "")
                        + (sales.EarnRate > 0m ? "earns " + earned + " pts   " : "")
                        + "(balance " + customerPoints + ")";
                }

                lblSubtotal.Text = Theme.Money(cart.Sum(l => l.RegularPrice * l.Quantity));   // items at regular prices
                decimal saved = cart.Sum(l => l.Savings);
                decimal allDiscount = saved + pointsDiscount;
                lblSavings.Text = allDiscount > 0m ? "-" + Theme.Money(allDiscount) : "-";
                lblTax.Text = Theme.Money(t.Tax) + (sales.TaxRate > 0 ? "  (" + sales.TaxRate.ToString("0.##") + "%)" : "");
                lblTotal.Text = Theme.Money(t.Total);

                bool cash = (string)cboPayment.SelectedItem == "Cash";
                numPaid.Enabled = cash;
                if (!cash) numPaid.Value = Math.Min(numPaid.Maximum, t.Total);

                lblChange.Text = numPaid.Value >= t.Total && cart.Count > 0 ? Theme.Money(numPaid.Value - t.Total) : "-";
                btnCheckout.Enabled = cart.Count > 0;
            }
            finally
            {
                updating = false;
            }
        }

        // ---------------- checkout ----------------

        private void DoCheckout()
        {
            if (cart.Count == 0) return;
            try
            {
                var order = sales.Checkout(cart.ToList(), (string)cboPayment.SelectedItem, numPaid.Value, customerId, (int)numPoints.Value);

                SetCustomer(null);
                cart.Clear();
                updating = true;
                numPoints.Value = 0;
                numPaid.Value = 0;
                updating = false;
                RefreshCart();
                RunSearch();
                SetStatus("Sale " + order.OrderNumber + " completed.", false);

                var answer = MessageBox.Show(this,
                    string.Format("Sale {0} completed.\n\nTotal: {1}\nChange: {2}{3}\n\nOpen the receipt?",
                        order.OrderNumber, Theme.Money(order.Total), Theme.Money(order.ChangeDue),
                        order.PointsEarned > 0 || order.PointsRedeemed > 0
                            ? string.Format("\nPoints earned: {0}   used: {1}   balance: {2}",
                                order.PointsEarned, order.PointsRedeemed, order.CustomerPoints)
                            : string.Empty),
                    "Sale complete", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (answer == DialogResult.Yes) ReceiptPrinter.ShowPreview(this, order);
                txtScan.Focus();
            }
            catch (InvalidOperationException ex)
            {
                // Validation and stock messages are written for the user.
                MessageBox.Show(this, ex.Message, "Cannot complete sale", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                RunSearch();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "The sale could not be saved. Nothing was charged and stock was not changed.\n\n" + ex.Message,
                    "Database error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                updating = false;
            }
        }

        private void PickCustomer()
        {
            using (var dlg = new CustomerPickerForm(user))
            {
                if (dlg.ShowDialog(this) == DialogResult.OK) SetCustomer(dlg.SelectedCustomer);
            }
            txtScan.Focus();
        }

        /// <summary>null = walk-in sale.</summary>
        private void SetCustomer(Customer customer)
        {
            customerId = customer == null ? (int?)null : customer.CustomerId;
            customerPoints = customer == null ? 0 : customer.LoyaltyPoints;
            btnCustomer.Text = customer == null
                ? "Walk-in customer (change)"
                : customer.FullName + "  -  " + customer.LoyaltyPoints + " pts";
            numPoints.Value = 0;   // points set for the previous customer must not carry over
            foreach (var l in cart) l.BulkAllowed = customerId.HasValue;   // bulk prices are for customers only
            RefreshCart();
        }

        private void SetStatus(string text, bool isError)
        {
            lblStatus.ForeColor = isError ? Theme.Rose : Theme.Muted;
            lblStatus.Text = text;
        }
    }
}
