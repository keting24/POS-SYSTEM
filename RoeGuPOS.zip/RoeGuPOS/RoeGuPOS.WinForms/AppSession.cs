using RoeGuPOS.Domain;

namespace RoeGuPOS.WinForms
{
    /// <summary>Holds the signed-in user for the lifetime of a login.</summary>
    internal static class AppSession
    {
        public static User CurrentUser { get; set; }
    }
}
