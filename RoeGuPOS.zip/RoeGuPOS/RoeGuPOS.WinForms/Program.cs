using System;
using System.Threading;
using System.Windows.Forms;
using RoeGuPOS.Domain;

namespace RoeGuPOS.WinForms
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            // Must run before any window is created.
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) => Report(e.Exception, "UI thread");
            AppDomain.CurrentDomain.UnhandledException += (s, e) => Report(e.ExceptionObject as Exception, "Background thread");

            ErrorLog.Purge(14);
            Currency.Symbol = Theme.CurrencySymbol;   // the peso sign (or App.config CurrencySymbol) for all display text

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Login -> Dashboard. Logging out returns to the login form.
            while (true)
            {
                using (var login = new LoginForm())
                {
                    if (login.ShowDialog() != DialogResult.OK) return;
                }

                using (var main = new MainForm())
                {
                    Application.Run(main);
                    if (!main.LoggedOut) return;
                }
                AppSession.CurrentUser = null;
            }
        }

        /// <summary>Logs the full error and shows a safe message (no SQL, paths or connection details).</summary>
        private static void Report(Exception ex, string context)
        {
            if (ex == null) return;
            var id = ErrorLog.Write(ex, context);
            MessageBox.Show(
                "Something went wrong and the action could not be completed.\n\n" +
                "Please try again. If it keeps happening, give this reference to your administrator:\n\n" + id,
                "RoeGuPOS", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
