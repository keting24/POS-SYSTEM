using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Add or remove loyalty points by hand, with a required reason (Admin and Manager).</summary>
    public sealed class PointsAdjustForm : Form
    {
        private readonly CustomerService service;
        private readonly Customer customer;
        private readonly NumericUpDown numChange = new NumericUpDown();
        private readonly TextBox txtReason = new TextBox();

        public PointsAdjustForm(CustomerService service, Customer customer)
        {
            this.service = service;
            this.customer = customer;

            Text = "Adjust points";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(400, 240);
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            Controls.Add(new Label
            {
                Text = string.Format("{0}\nCurrent balance: {1} pts", customer.FullName, customer.LoyaltyPoints),
                AutoSize = true,
                Location = new Point(16, 14)
            });

            Controls.Add(new Label { Text = "Change (+ add / - remove)", AutoSize = true, Location = new Point(16, 66) });
            numChange.Location = new Point(16, 90);
            numChange.Width = 160;
            numChange.Minimum = -1000000;
            numChange.Maximum = 1000000;
            Controls.Add(numChange);

            Controls.Add(new Label { Text = "Reason *", AutoSize = true, Location = new Point(16, 124) });
            txtReason.Location = new Point(16, 146);
            txtReason.Width = 368;
            txtReason.MaxLength = 180;
            Controls.Add(txtReason);

            var btnSave = new Button { Text = "Apply", Location = new Point(144, 190), Size = new Size(112, 36) };
            var btnCancel = new Button { Text = "Cancel", Location = new Point(272, 190), Size = new Size(112, 36), DialogResult = DialogResult.Cancel };
            Theme.Primary(btnSave);
            Theme.Soft(btnCancel);
            btnSave.Click += (s, e) => Apply();
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            AcceptButton = btnSave;
            CancelButton = btnCancel;
        }

        private void Apply()
        {
            try
            {
                service.AdjustPoints(customer.CustomerId, (int)numChange.Value, txtReason.Text);
                DialogResult = DialogResult.OK;
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Adjust points", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not change the points.\n\n" + ex.Message, "Adjust points",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    /// <summary>Read-only ledger of one customer's loyalty points (newest first, up to 200 rows).</summary>
    public sealed class PointsHistoryForm : Form
    {
        private readonly List<LoyaltyMovement> rows;

        public PointsHistoryForm(CustomerService service, Customer customer)
        {
            Text = "Points history";
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            MinimizeBox = false;
            ClientSize = new Size(700, 420);
            MinimumSize = new Size(520, 320);
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            try { rows = service.PointsHistory(customer.CustomerId); }
            catch (Exception ex)
            {
                rows = new List<LoyaltyMovement>();
                MessageBox.Show("Could not load the history.\n\n" + ex.Message, "Points history",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            var title = new Label
            {
                Text = customer.FullName + " - " + customer.LoyaltyPoints + " pts",
                Font = Theme.Bold(14f),
                AutoSize = true,
                Dock = DockStyle.Top,
                Padding = new Padding(16, 14, 0, 8)
            };

            var grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                RowHeadersVisible = false,
                AutoGenerateColumns = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };
            Theme.StyleGrid(grid);
            grid.Columns.Add(Col("CreatedAt", "When", 150, "g"));
            grid.Columns.Add(Col("Points", "Points", 80, "+0;-0;0"));
            grid.Columns.Add(Col("Reason", "Reason", 0, null));
            grid.Columns.Add(Col("UserName", "By", 140, null));
            grid.Columns["Reason"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            grid.Columns["Points"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            grid.DataSource = rows;
            grid.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0 || e.RowIndex >= rows.Count) return;
                if (grid.Columns[e.ColumnIndex].Name == "Points" && rows[e.RowIndex].Points < 0)
                    e.CellStyle.ForeColor = Theme.Rose;
            };

            var host = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16, 0, 16, 0) };
            host.Controls.Add(grid);

            var bottom = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 52, Padding = new Padding(16, 8, 8, 0), FlowDirection = FlowDirection.RightToLeft };
            var btnClose = new Button { Text = "Close", Size = new Size(100, 34) };
            Theme.Soft(btnClose);
            btnClose.Click += (s, e) => Close();
            bottom.Controls.Add(btnClose);

            Controls.Add(host);
            Controls.Add(bottom);
            Controls.Add(title);
        }

        private static DataGridViewTextBoxColumn Col(string property, string header, int width, string format)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName = property, HeaderText = header, Name = property };
            if (width > 0) c.Width = width;
            if (format != null) c.DefaultCellStyle.Format = format;
            return c;
        }
    }
}
