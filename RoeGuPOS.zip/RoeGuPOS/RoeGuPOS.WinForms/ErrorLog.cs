using System;
using System.IO;
using System.Text;

namespace RoeGuPOS.WinForms
{
    /// <summary>
    /// Writes unexpected errors to %LocalAppData%\RoeGuPOS\logs\roegupos-yyyyMMdd.log (one file per day,
    /// files older than 14 days are deleted). Logs never contain passwords or connection strings.
    /// </summary>
    internal static class ErrorLog
    {
        private static readonly object Gate = new object();

        public static string Folder
        {
            get
            {
                return Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "RoeGuPOS", "logs");
            }
        }

        /// <summary>Appends the error and returns a short reference id to show the user.</summary>
        public static string Write(Exception ex, string context)
        {
            var id = Guid.NewGuid().ToString("N").Substring(0, 8).ToUpperInvariant();
            try
            {
                var user = AppSession.CurrentUser;
                var sb = new StringBuilder();
                sb.Append('[').Append(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")).Append("] ref ").Append(id);
                sb.Append(" | ").Append(context);
                sb.Append(" | user: ").AppendLine(user == null ? "(not signed in)" : user.Username);

                int depth = 0;
                for (var e = ex; e != null && depth < 5; e = e.InnerException, depth++)
                {
                    sb.Append(depth == 0 ? "  " : "  caused by ").Append(e.GetType().FullName).Append(": ").AppendLine(e.Message);
                    if (e.StackTrace != null) sb.AppendLine(e.StackTrace);
                }
                sb.AppendLine();

                lock (Gate)
                {
                    Directory.CreateDirectory(Folder);
                    var file = Path.Combine(Folder, "roegupos-" + DateTime.Now.ToString("yyyyMMdd") + ".log");
                    File.AppendAllText(file, sb.ToString(), Encoding.UTF8);
                }
                return id;
            }
            catch
            {
                // Logging must never crash the app.
                return id + " (not logged)";
            }
        }

        /// <summary>Deletes log files older than the given number of days.</summary>
        public static void Purge(int keepDays)
        {
            try
            {
                if (!Directory.Exists(Folder)) return;
                var limit = DateTime.Now.AddDays(-keepDays);
                foreach (var file in Directory.GetFiles(Folder, "roegupos-*.log"))
                    if (File.GetLastWriteTime(file) < limit) File.Delete(file);
            }
            catch
            {
                // Ignore: housekeeping only.
            }
        }
    }
}
