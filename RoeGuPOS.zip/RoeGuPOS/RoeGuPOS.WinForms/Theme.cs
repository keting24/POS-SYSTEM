using System.Configuration;
using System.Drawing;
using System.Windows.Forms;

namespace RoeGuPOS.WinForms
{
    /// <summary>One place for the app's colors and control styling so every screen matches.</summary>
    internal static class Theme
    {
        // Palette
        public static readonly Color Sage = ColorTranslator.FromHtml("#99B898");
        public static readonly Color Peach = ColorTranslator.FromHtml("#FECEA8");
        public static readonly Color Coral = ColorTranslator.FromHtml("#FF847C");
        public static readonly Color Rose = ColorTranslator.FromHtml("#E84A5F");
        public static readonly Color Slate = ColorTranslator.FromHtml("#2A363B");

        // Derived neutrals
        public static readonly Color Background = Color.FromArgb(251, 246, 241); // very light peach tint
        public static readonly Color Surface = Color.White;
        public static readonly Color SlateHover = Color.FromArgb(58, 76, 83);
        public static readonly Color Muted = Color.FromArgb(104, 118, 124);
        public static readonly Color NavText = Color.FromArgb(205, 218, 205);
        public static readonly Color RowAlt = Color.FromArgb(250, 243, 236);

        /// <summary>
        /// Currency symbol shown before amounts. App.config key CurrencySymbol; default is the peso sign.
        /// Set the key to an empty value to show plain numbers.
        /// </summary>
        public static string CurrencySymbol
        {
            get
            {
                var v = ConfigurationManager.AppSettings["CurrencySymbol"];
                return v == null ? "\u20B1" : v.Trim();
            }
        }

        /// <summary>1234.5 becomes "&#8369;1,234.50".</summary>
        public static string Money(decimal value)
        {
            return CurrencySymbol + value.ToString("N2");
        }

        /// <summary>Cell format for money columns in grids.</summary>
        public static string MoneyFormat
        {
            get
            {
                var sym = CurrencySymbol;
                return sym.Length == 0 ? "N2" : "\"" + sym.Replace("\"", "") + "\"#,##0.00";
            }
        }

        public static Font Base(float size) { return new Font("Segoe UI", size); }
        public static Font Bold(float size) { return new Font("Segoe UI", size, FontStyle.Bold); }

        /// <summary>Flat colored button. Hover shades the button slightly.</summary>
        public static void StyleButton(Button b, Color back, Color fore)
        {
            b.FlatStyle = FlatStyle.Flat;
            b.FlatAppearance.BorderSize = 0;
            b.BackColor = back;
            b.ForeColor = fore;
            b.Cursor = Cursors.Hand;
            b.UseVisualStyleBackColor = false;
            b.FlatAppearance.MouseOverBackColor = ControlPaint.Light(back, 0.15f);
            b.FlatAppearance.MouseDownBackColor = ControlPaint.Dark(back, 0.05f);
        }

        public static void Primary(Button b) { StyleButton(b, Rose, Color.White); }
        public static void Secondary(Button b) { StyleButton(b, Sage, Slate); }
        public static void Accent(Button b) { StyleButton(b, Coral, Slate); }
        public static void Soft(Button b) { StyleButton(b, Peach, Slate); }
        public static void Dark(Button b) { StyleButton(b, Slate, Color.White); }

        public static void StyleGrid(DataGridView g)
        {
            g.BackgroundColor = Surface;
            g.BorderStyle = BorderStyle.None;
            g.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            g.GridColor = Color.FromArgb(236, 228, 220);
            g.EnableHeadersVisualStyles = false;
            g.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            g.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            g.ColumnHeadersHeight = 38;
            g.ColumnHeadersDefaultCellStyle.BackColor = Slate;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            g.ColumnHeadersDefaultCellStyle.SelectionBackColor = Slate;
            g.ColumnHeadersDefaultCellStyle.Font = Bold(9.5f);
            g.RowTemplate.Height = 32;
            g.DefaultCellStyle.BackColor = Surface;
            g.DefaultCellStyle.ForeColor = Slate;
            g.DefaultCellStyle.SelectionBackColor = Sage;
            g.DefaultCellStyle.SelectionForeColor = Slate;
            g.AlternatingRowsDefaultCellStyle.BackColor = RowAlt;
        }
    }
}
