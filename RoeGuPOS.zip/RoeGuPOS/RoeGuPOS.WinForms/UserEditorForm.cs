using System;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    public enum UserEditorMode { Create, Edit, ResetPassword }

    /// <summary>One dialog for adding a user, editing a user, or resetting a password.</summary>
    public sealed class UserEditorForm : Form
    {
        private readonly UserAdminService service;
        private readonly UserEditorMode mode;
        private readonly ManagedUser existing;
        private readonly bool editingSelf;

        private readonly TextBox txtUsername = new TextBox();
        private readonly TextBox txtFullName = new TextBox();
        private readonly ComboBox cboRole = new ComboBox();
        private readonly CheckBox chkActive = new CheckBox();
        private readonly TextBox txtPassword = new TextBox();
        private readonly TextBox txtConfirm = new TextBox();

        public UserEditorForm(UserAdminService service, UserEditorMode mode, ManagedUser existing, bool editingSelf)
        {
            this.service = service;
            this.mode = mode;
            this.existing = existing;
            this.editingSelf = editingSelf;

            Text = mode == UserEditorMode.Create ? "Add user"
                 : mode == UserEditorMode.Edit ? "Edit user" : "Reset password";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            txtUsername.MaxLength = 50;
            txtFullName.MaxLength = 100;
            txtPassword.MaxLength = 100;
            txtConfirm.MaxLength = 100;
            txtPassword.UseSystemPasswordChar = true;
            txtConfirm.UseSystemPasswordChar = true;
            cboRole.DropDownStyle = ComboBoxStyle.DropDownList;
            chkActive.Text = "Active (can sign in)";

            int y = 18;
            AddRow("Username" + (mode != UserEditorMode.ResetPassword ? " *" : ""), txtUsername, ref y);
            if (mode != UserEditorMode.ResetPassword)
            {
                AddRow("Full name *", txtFullName, ref y);
                AddRow("Role *", cboRole, ref y);
            }
            if (mode == UserEditorMode.Edit)
            {
                chkActive.Location = new Point(150, y);
                chkActive.AutoSize = true;
                Controls.Add(chkActive);
                y += 34;
                if (editingSelf)
                {
                    Controls.Add(new Label
                    {
                        Text = "You cannot change your own role or disable your own account.",
                        ForeColor = Theme.Muted,
                        Font = Theme.Base(9f),
                        Location = new Point(16, y),
                        Size = new Size(384, 34)
                    });
                    y += 38;
                }
            }
            if (mode != UserEditorMode.Edit)
            {
                AddRow(mode == UserEditorMode.Create ? "Password *" : "New password *", txtPassword, ref y);
                AddRow("Confirm password *", txtConfirm, ref y);
                Controls.Add(new Label
                {
                    Text = "At least 8 characters, with a letter and a number.",
                    ForeColor = Theme.Muted,
                    Font = Theme.Base(9f),
                    AutoSize = true,
                    Location = new Point(150, y - 6)
                });
                y += 26;
            }

            ClientSize = new Size(420, y + 62);

            var btnSave = new Button { Text = "Save", Location = new Point(150, y + 8), Size = new Size(120, 36) };
            var btnCancel = new Button { Text = "Cancel", Location = new Point(280, y + 8), Size = new Size(120, 36), DialogResult = DialogResult.Cancel };
            Theme.Primary(btnSave);
            Theme.Soft(btnCancel);
            btnSave.Click += (s, e) => Save();
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            AcceptButton = btnSave;
            CancelButton = btnCancel;

            Load += (s, e) => LoadValues();
        }

        private void AddRow(string label, Control input, ref int y)
        {
            Controls.Add(new Label { Text = label, AutoSize = true, Location = new Point(16, y + 4) });
            input.Location = new Point(150, y);
            input.Width = 250;
            Controls.Add(input);
            y += 40;
        }

        private void LoadValues()
        {
            try
            {
                if (mode != UserEditorMode.ResetPassword)
                {
                    cboRole.DisplayMember = "RoleName";
                    cboRole.ValueMember = "RoleId";
                    cboRole.DataSource = service.Roles();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not load the roles.\n\n" + ex.Message, "Users",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult = DialogResult.Cancel;
                return;
            }

            if (mode == UserEditorMode.Create) return;

            txtUsername.Text = existing.Username;
            if (mode == UserEditorMode.ResetPassword)
            {
                txtUsername.ReadOnly = true;   // only Edit may change the username
                txtUsername.BackColor = Color.FromArgb(240, 234, 228);
            }

            if (mode == UserEditorMode.Edit)
            {
                txtFullName.Text = existing.FullName;
                cboRole.SelectedValue = existing.RoleId;
                chkActive.Checked = existing.IsActive;
                if (editingSelf)
                {
                    cboRole.Enabled = false;
                    chkActive.Enabled = false;
                }
            }
        }

        private void Save()
        {
            try
            {
                if (mode != UserEditorMode.Edit && txtPassword.Text != txtConfirm.Text)
                {
                    MessageBox.Show(this, "The two passwords do not match.", "Users", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtConfirm.Clear();
                    txtConfirm.Focus();
                    return;
                }

                switch (mode)
                {
                    case UserEditorMode.Create:
                        if (cboRole.SelectedValue == null) throw new InvalidOperationException("Choose a role.");
                        service.Create(txtUsername.Text, txtFullName.Text, (int)cboRole.SelectedValue, txtPassword.Text);
                        break;
                    case UserEditorMode.Edit:
                        if (cboRole.SelectedValue == null) throw new InvalidOperationException("Choose a role.");
                        service.Update(existing.UserId, txtUsername.Text, txtFullName.Text, (int)cboRole.SelectedValue, chkActive.Checked);
                        break;
                    default:
                        service.ResetPassword(existing.UserId, txtPassword.Text);
                        break;
                }
                DialogResult = DialogResult.OK;
            }
            catch (InvalidOperationException ex)
            {
                // Validation messages are written for the user.
                MessageBox.Show(this, ex.Message, "Users", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not save.\n\n" + ex.Message, "Users", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
