using System;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Add or remove stock with a required reason. Writes to dbo.InventoryLog.</summary>
    public sealed class StockAdjustForm : Form
    {
        private readonly InventoryService service;
        private readonly Product product;
        private readonly NumericUpDown numChange = new NumericUpDown();
        private readonly TextBox txtReason = new TextBox();

        public StockAdjustForm(InventoryService service, Product product)
        {
            this.service = service;
            this.product = product;

            Text = "Adjust stock";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            Font = new Font("Segoe UI", 10f);
            ClientSize = new Size(400, 240);

            Controls.Add(new Label
            {
                Text = string.Format("{0}\nCurrent stock: {1}", product.Name, product.StockQty),
                AutoSize = true,
                Location = new Point(16, 14)
            });

            Controls.Add(new Label { Text = "Change (+ add / - remove)", AutoSize = true, Location = new Point(16, 66) });
            numChange.Location = new Point(16, 90);
            numChange.Width = 160;
            numChange.Minimum = -1000000;
            numChange.Maximum = 1000000;
            Controls.Add(numChange);

            Controls.Add(new Label { Text = "Reason *", AutoSize = true, Location = new Point(16, 124) });
            txtReason.Location = new Point(16, 146);
            txtReason.Width = 368;
            txtReason.MaxLength = 200;
            Controls.Add(txtReason);

            var btnSave = new Button { Text = "Apply", Location = new Point(144, 192), Size = new Size(112, 34) };
            var btnCancel = new Button { Text = "Cancel", Location = new Point(272, 192), Size = new Size(112, 34), DialogResult = DialogResult.Cancel };
            btnSave.Click += (s, e) => Apply();
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            AcceptButton = btnSave;
            CancelButton = btnCancel;
        }

        private void Apply()
        {
            try
            {
                service.AdjustStock(product.ProductId, (int)numChange.Value, txtReason.Text);
                DialogResult = DialogResult.OK;
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Adjust stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not adjust stock.\n\n" + ex.Message, "Adjust stock",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
