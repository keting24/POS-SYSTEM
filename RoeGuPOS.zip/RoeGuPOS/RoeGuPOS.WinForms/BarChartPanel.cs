using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace RoeGuPOS.WinForms
{
    /// <summary>A small bar chart drawn with GDI+ (no chart library needed). One scale for bars, grid and labels.</summary>
    internal sealed class BarChartPanel : Panel
    {
        private List<KeyValuePair<string, decimal>> data = new List<KeyValuePair<string, decimal>>();

        public string EmptyText { get; set; }

        public BarChartPanel()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
            BackColor = Theme.Surface;
            EmptyText = "No sales in this period.";
        }

        public void SetData(IEnumerable<KeyValuePair<string, decimal>> values)
        {
            data = values.ToList();
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;

            const int left = 70, right = 16, top = 18, bottom = 34;
            var plot = new Rectangle(left, top, Math.Max(10, Width - left - right), Math.Max(10, Height - top - bottom));

            using (var font = Theme.Base(8.5f))
            using (var textBrush = new SolidBrush(Theme.Muted))
            using (var gridPen = new Pen(Color.FromArgb(236, 228, 220)))
            using (var barBrush = new SolidBrush(Theme.Rose))
            using (var centered = new StringFormat { Alignment = StringAlignment.Center })
            using (var rightAligned = new StringFormat { Alignment = StringAlignment.Far })
            {
                decimal max = data.Count == 0 ? 0m : data.Max(d => d.Value);
                if (data.Count == 0 || max <= 0m)
                {
                    using (var f = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                        g.DrawString(EmptyText, Theme.Base(10f), textBrush, new RectangleF(0, 0, Width, Height), f);
                    return;
                }

                decimal axisMax = NiceMax(max);
                const int ticks = 4;

                for (int i = 0; i <= ticks; i++)
                {
                    float y = plot.Bottom - plot.Height * i / (float)ticks;
                    g.DrawLine(gridPen, plot.Left, y, plot.Right, y);
                    var label = (axisMax * i / ticks).ToString("N0");
                    g.DrawString(label, font, textBrush, new RectangleF(0, y - 8, left - 8, 16), rightAligned);
                }

                float slot = plot.Width / (float)data.Count;
                float barW = Math.Max(2f, slot * 0.62f);
                int labelEvery = Math.Max(1, (int)Math.Ceiling(data.Count / Math.Max(1.0, plot.Width / 64.0)));
                bool showValues = slot >= 52f;

                for (int i = 0; i < data.Count; i++)
                {
                    float x = plot.Left + slot * i + (slot - barW) / 2f;
                    float h = (float)(data[i].Value / axisMax) * plot.Height;
                    if (data[i].Value > 0m)
                        g.FillRectangle(barBrush, x, plot.Bottom - h, barW, Math.Max(1f, h));

                    if (i % labelEvery == 0)
                        g.DrawString(data[i].Key, font, textBrush, new RectangleF(plot.Left + slot * i - 10, plot.Bottom + 6, slot + 20, 16), centered);

                    if (showValues && data[i].Value > 0m)
                        g.DrawString(data[i].Value.ToString("N0"), font, textBrush, new RectangleF(x - 14, plot.Bottom - h - 16, barW + 28, 14), centered);
                }
            }
        }

        /// <summary>Rounds the maximum up to 1, 2, 5 or 10 times a power of ten.</summary>
        private static decimal NiceMax(decimal max)
        {
            double m = (double)max;
            double magnitude = Math.Pow(10, Math.Floor(Math.Log10(m)));
            double f = m / magnitude;
            double nice = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
            return (decimal)(nice * magnitude);
        }
    }
}
