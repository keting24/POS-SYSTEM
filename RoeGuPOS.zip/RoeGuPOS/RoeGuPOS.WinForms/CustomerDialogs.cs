using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Add / edit one customer.</summary>
    public sealed class CustomerEditorForm : Form
    {
        private readonly CustomerService service;
        private readonly Customer customer;
        private readonly TextBox txtName = new TextBox();
        private readonly TextBox txtPhone = new TextBox();
        private readonly TextBox txtEmail = new TextBox();
        private readonly TextBox txtAddress = new TextBox();

        /// <summary>The saved customer (with its id) after the dialog returns OK.</summary>
        public Customer Saved { get { return customer; } }

        public CustomerEditorForm(CustomerService service, Customer existing)
        {
            this.service = service;
            customer = existing ?? new Customer();

            Text = existing == null ? "Add customer" : "Edit customer";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            ClientSize = new Size(440, 290);
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            txtName.MaxLength = 100;
            txtPhone.MaxLength = 30;
            txtEmail.MaxLength = 120;
            txtAddress.MaxLength = 250;
            txtAddress.Multiline = true;
            txtAddress.Height = 60;

            int y = 18;
            AddRow("Name *", txtName, ref y);
            AddRow("Phone", txtPhone, ref y);
            AddRow("Email", txtEmail, ref y);
            AddRow("Address", txtAddress, ref y);

            var btnSave = new Button { Text = "Save", Location = new Point(150, 236), Size = new Size(130, 36) };
            var btnCancel = new Button { Text = "Cancel", Location = new Point(290, 236), Size = new Size(130, 36), DialogResult = DialogResult.Cancel };
            Theme.Primary(btnSave);
            Theme.Soft(btnCancel);
            btnSave.Click += (s, e) => Save();
            Controls.Add(btnSave);
            Controls.Add(btnCancel);
            AcceptButton = btnSave;
            CancelButton = btnCancel;

            txtName.Text = customer.FullName;
            txtPhone.Text = customer.Phone;
            txtEmail.Text = customer.Email;
            txtAddress.Text = customer.Address;
        }

        private void AddRow(string label, Control input, ref int y)
        {
            Controls.Add(new Label { Text = label, AutoSize = true, Location = new Point(16, y + 4) });
            input.Location = new Point(150, y);
            input.Width = 270;
            Controls.Add(input);
            y += input.Height + 14;
        }

        private void Save()
        {
            customer.FullName = txtName.Text;
            customer.Phone = txtPhone.Text;
            customer.Email = txtEmail.Text;
            customer.Address = txtAddress.Text;
            try
            {
                customer.CustomerId = service.Save(customer);
                DialogResult = DialogResult.OK;
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, "Customers", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not save the customer.\n\n" + ex.Message, "Customers", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }

    /// <summary>Pick the customer for a sale, or choose walk-in (no customer).</summary>
    public sealed class CustomerPickerForm : Form
    {
        private readonly CustomerService service;
        private readonly TextBox txtSearch = new TextBox();
        private readonly DataGridView grid = new DataGridView();
        private readonly Timer searchTimer = new Timer();
        private List<Customer> current = new List<Customer>();

        /// <summary>The chosen customer, or null for a walk-in sale. Valid when the dialog returns OK.</summary>
        public Customer SelectedCustomer { get; private set; }

        public CustomerPickerForm(User user)
        {
            service = new CustomerService(user);
            Text = "Select customer";
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            MinimizeBox = false;
            ClientSize = new Size(640, 440);
            MinimumSize = new Size(520, 340);
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 56, Padding = new Padding(16, 10, 8, 0), WrapContents = false };
            top.Controls.Add(new Label { Text = "Search:", AutoSize = true, Margin = new Padding(0, 8, 4, 0) });
            txtSearch.Width = 220;
            txtSearch.Margin = new Padding(0, 5, 12, 0);
            txtSearch.BorderStyle = BorderStyle.FixedSingle;
            txtSearch.TextChanged += (s, e) => { searchTimer.Stop(); searchTimer.Start(); };
            txtSearch.KeyDown += (s, e) => { if (e.KeyCode == Keys.Down) grid.Focus(); };
            searchTimer.Interval = 300;
            searchTimer.Tick += (s, e) => { searchTimer.Stop(); ReloadData(); };
            top.Controls.Add(txtSearch);
            top.Controls.Add(MakeButton("New customer", Theme.Secondary, (s, e) => AddNew()));

            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.MultiSelect = false;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.AutoGenerateColumns = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Theme.StyleGrid(grid);
            grid.Columns.Add(Col("FullName", "Name", 0));
            grid.Columns.Add(Col("Phone", "Phone", 150));
            grid.Columns.Add(Col("Email", "Email", 190));
            grid.Columns.Add(Col("LoyaltyPoints", "Points", 80));
            grid.Columns["LoyaltyPoints"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            grid.Columns["FullName"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) UseSelected(); };
            grid.KeyDown += (s, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; UseSelected(); } };

            var bottom = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 54, Padding = new Padding(16, 8, 8, 0), WrapContents = false };
            bottom.Controls.Add(MakeButton("Use selected", Theme.Primary, (s, e) => UseSelected()));
            bottom.Controls.Add(MakeButton("Walk-in (no customer)", Theme.Accent, (s, e) => { SelectedCustomer = null; DialogResult = DialogResult.OK; }));
            bottom.Controls.Add(MakeButton("Cancel", Theme.Soft, (s, e) => { DialogResult = DialogResult.Cancel; }));

            var host = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16, 0, 16, 0) };
            host.Controls.Add(grid);

            Controls.Add(host);
            Controls.Add(bottom);
            Controls.Add(top);

            Load += (s, e) => { ReloadData(); txtSearch.Focus(); };
        }

        private static Button MakeButton(string text, Action<Button> style, EventHandler click)
        {
            var b = new Button { Text = text, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, MinimumSize = new Size(86, 34), Padding = new Padding(10, 0, 10, 0), Margin = new Padding(0, 0, 8, 0) };
            style(b);
            b.Click += click;
            return b;
        }

        private static DataGridViewTextBoxColumn Col(string property, string header, int width)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName = property, HeaderText = header, Name = property };
            if (width > 0) c.Width = width;
            return c;
        }

        private void ReloadData()
        {
            try
            {
                current = service.Search(txtSearch.Text);
                grid.DataSource = null;
                grid.DataSource = current;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not load customers.\n\n" + ex.Message, "Customers", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UseSelected()
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Index < 0 || grid.CurrentRow.Index >= current.Count)
            {
                MessageBox.Show(this, "Select a customer, or choose Walk-in.", "Customers", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            SelectedCustomer = current[grid.CurrentRow.Index];
            DialogResult = DialogResult.OK;
        }

        private void AddNew()
        {
            using (var dlg = new CustomerEditorForm(service, null))
            {
                if (dlg.ShowDialog(this) != DialogResult.OK) return;
                SelectedCustomer = dlg.Saved;   // use the new customer straight away
                DialogResult = DialogResult.OK;
            }
        }
    }
}
