using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Module 3: product list with Create / Read / Update / Delete and stock adjustment.</summary>
    public sealed class ProductForm : Form
    {
        private readonly InventoryService service;
        private readonly User user;

        private readonly TextBox txtSearch = new TextBox();
        private readonly CheckBox chkInactive = new CheckBox();
        private readonly DataGridView grid = new DataGridView();
        private readonly Label lblCount = new Label();
        private List<Product> current = new List<Product>();

        public ProductForm(User user)
        {
            this.user = user;
            service = new InventoryService(user);
            Text = "Inventory";
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            BuildLayout();
        }

        private void BuildLayout()
        {
            var heading = new Label
            {
                Text = "Inventory",
                Font = Theme.Bold(20f),
                ForeColor = Theme.Slate,
                AutoSize = true,
                Dock = DockStyle.Top,
                Padding = new Padding(28, 24, 0, 6)
            };

            // Wraps onto a second row on narrow windows instead of cutting buttons off.
            var top = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Padding = new Padding(24, 10, 12, 6),
                WrapContents = true,
                BackColor = Theme.Background
            };

            var lblSearch = new Label { Text = "Search (SKU, name, category):", ForeColor = Theme.Slate, AutoSize = true, Margin = new Padding(0, 8, 4, 0) };
            txtSearch.Width = 240;
            txtSearch.Margin = new Padding(0, 5, 0, 0);
            txtSearch.BorderStyle = BorderStyle.FixedSingle;
            txtSearch.TextChanged += (s, e) => { searchTimer.Stop(); searchTimer.Start(); };
            chkInactive.Text = "Show deleted";
            chkInactive.AutoSize = true;
            chkInactive.ForeColor = Theme.Slate;
            chkInactive.Margin = new Padding(14, 8, 14, 0);
            chkInactive.CheckedChanged += (s, e) => ReloadData();

            var btnAdd = MakeButton("Add", (s, e) => AddProduct(), Theme.Primary);
            var btnEdit = MakeButton("Edit", (s, e) => EditSelected(), Theme.Secondary);
            var btnStock = MakeButton("Adjust stock", (s, e) => AdjustSelected(), Theme.Accent);
            var btnDelete = MakeButton("Delete", (s, e) => DeleteSelected(), Theme.Dark);
            var btnRefresh = MakeButton("Refresh", (s, e) => ReloadData(), Theme.Soft);
            var btnCategories = MakeButton("Categories", (s, e) => OpenCategories(), Theme.Soft);
            var btnHistory = MakeButton("Stock history", (s, e) => OpenHistory(), Theme.Soft);

            top.Controls.AddRange(new Control[] { lblSearch, txtSearch, chkInactive, btnAdd, btnEdit, btnStock, btnDelete, btnCategories, btnHistory, btnRefresh });

            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.MultiSelect = false;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.AutoGenerateColumns = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Theme.StyleGrid(grid);
            grid.Columns.Add(Col("Sku", "SKU", 100, null));
            grid.Columns.Add(Col("Barcode", "Barcode", 130, null));
            grid.Columns.Add(Col("Name", "Product", 0, null));
            grid.Columns.Add(Col("CategoryName", "Category", 120, null));
            grid.Columns.Add(Col("Price", "Price", 80, Theme.MoneyFormat));
            grid.Columns.Add(Col("Cost", "Cost", 80, Theme.MoneyFormat));
            grid.Columns.Add(Col("BulkText", "Bulk price", 110, null));
            grid.Columns.Add(Col("StockQty", "Stock", 70, null));
            grid.Columns.Add(Col("ReorderLevel", "Reorder", 75, null));
            grid.Columns.Add(Col("IsActive", "Active", 60, null));
            grid.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            grid.CellDoubleClick += (s, e) => { if (e.RowIndex >= 0) EditSelected(); };
            grid.CellFormatting += GridCellFormatting;

            lblCount.Dock = DockStyle.Bottom;
            lblCount.Height = 30;
            lblCount.ForeColor = Theme.Muted;
            lblCount.Padding = new Padding(28, 6, 0, 0);

            // Grid sits in a padded host so it lines up with the other screens.
            var gridHost = new Panel { Dock = DockStyle.Fill, Padding = new Padding(28, 0, 28, 0), BackColor = Theme.Background };
            gridHost.Controls.Add(grid);

            Controls.Add(gridHost);
            Controls.Add(lblCount);
            Controls.Add(top);
            Controls.Add(heading);

            searchTimer.Interval = 300;
            searchTimer.Tick += (s, e) => { searchTimer.Stop(); ReloadData(); };
        }

        private readonly Timer searchTimer = new Timer();

        private static Button MakeButton(string text, EventHandler onClick, Action<Button> style)
        {
            var b = new Button
            {
                Text = text,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Margin = new Padding(0, 4, 8, 0),
                Padding = new Padding(10, 0, 10, 0),
                Height = 34,
                MinimumSize = new Size(86, 34)
            };
            style(b);
            b.Click += onClick;
            return b;
        }

        private static DataGridViewTextBoxColumn Col(string property, string header, int width, string format)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName = property, HeaderText = header, Name = property };
            if (width > 0) c.Width = width;
            if (format != null) c.DefaultCellStyle.Format = format;
            return c;
        }

        private void GridCellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || e.RowIndex >= current.Count) return;
            var p = current[e.RowIndex];
            var row = grid.Rows[e.RowIndex];
            if (!p.IsActive) row.DefaultCellStyle.ForeColor = Color.Gray;
            else if (p.IsLowStock) row.DefaultCellStyle.BackColor = Theme.Peach;
        }

        public void ReloadData()
        {
            try
            {
                current = service.Search(txtSearch.Text, chkInactive.Checked);
                grid.DataSource = null;
                grid.DataSource = current;
                lblCount.Text = current.Count + " product(s)";
            }
            catch (Exception ex)
            {
                ShowError("Could not load products.", ex);
            }
        }

        private Product Selected()
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Index < 0 || grid.CurrentRow.Index >= current.Count) return null;
            return current[grid.CurrentRow.Index];
        }

        private void AddProduct()
        {
            try
            {
                using (var dlg = new ProductEditorForm(service, null))
                    if (dlg.ShowDialog(this) == DialogResult.OK) ReloadData();
            }
            catch (Exception ex) { ShowError("Could not open the product editor.", ex); }
        }

        private void EditSelected()
        {
            var p = Selected();
            if (p == null) { Info("Select a product first."); return; }
            try
            {
                using (var dlg = new ProductEditorForm(service, p))
                    if (dlg.ShowDialog(this) == DialogResult.OK) ReloadData();
            }
            catch (Exception ex) { ShowError("Could not open the product editor.", ex); }
        }

        private void AdjustSelected()
        {
            var p = Selected();
            if (p == null) { Info("Select a product first."); return; }
            using (var dlg = new StockAdjustForm(service, p))
                if (dlg.ShowDialog(this) == DialogResult.OK) ReloadData();
        }

        private void DeleteSelected()
        {
            var p = Selected();
            if (p == null) { Info("Select a product first."); return; }
            if (!p.IsActive) { Info("This product is already deleted."); return; }

            var answer = MessageBox.Show(this,
                string.Format("Delete \"{0}\"?\n\nIt will be hidden from sales and lists. Past sales are kept.", p.Name),
                "Confirm delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (answer != DialogResult.Yes) return;

            try
            {
                service.Delete(p.ProductId);
                ReloadData();
            }
            catch (Exception ex) { ShowError("Could not delete the product.", ex); }
        }

        private void OpenCategories()
        {
            using (var dlg = new CategoryManagerForm(user))
                dlg.ShowDialog(this);
            ReloadData(); // category names may have changed
        }

        private void OpenHistory()
        {
            using (var dlg = new StockHistoryForm(user, Selected()))
                dlg.ShowDialog(this);
        }

        private void Info(string text)
        {
            MessageBox.Show(this, text, "Inventory", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ShowError(string title, Exception ex)
        {
            MessageBox.Show(this, title + "\n\n" + ex.Message, "Inventory", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
