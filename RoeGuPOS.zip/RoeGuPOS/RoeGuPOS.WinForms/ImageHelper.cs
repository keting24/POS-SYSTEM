using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;

namespace RoeGuPOS.WinForms
{
    /// <summary>
    /// Safe handling of product pictures. A chosen file is checked, decoded and re-encoded as a small PNG,
    /// so the database never stores the original (untrusted) file bytes.
    /// </summary>
    internal static class ImageHelper
    {
        public const long MaxFileBytes = 5L * 1024 * 1024;
        public const int MaxSourceSide = 8000;
        public const int MaxStoredSide = 480;

        /// <summary>Reads a .jpg/.jpeg/.png file and returns PNG bytes no larger than 480 px on either side.</summary>
        public static byte[] LoadAndShrink(string path)
        {
            var ext = (Path.GetExtension(path) ?? string.Empty).ToLowerInvariant();
            if (ext != ".jpg" && ext != ".jpeg" && ext != ".png")
                throw new InvalidOperationException("Choose a .jpg, .jpeg or .png picture.");

            var info = new FileInfo(path);
            if (!info.Exists) throw new InvalidOperationException("That file could not be found.");
            if (info.Length > MaxFileBytes) throw new InvalidOperationException("The picture is larger than 5 MB.");

            byte[] source = File.ReadAllBytes(path);
            try
            {
                using (var input = new MemoryStream(source))
                using (var img = Image.FromStream(input))
                {
                    if (!img.RawFormat.Equals(ImageFormat.Jpeg) && !img.RawFormat.Equals(ImageFormat.Png))
                        throw new InvalidOperationException("The file is not a real JPG or PNG picture.");
                    if (img.Width > MaxSourceSide || img.Height > MaxSourceSide)
                        throw new InvalidOperationException("The picture is too large (maximum 8000 pixels on a side).");

                    double scale = Math.Min(1.0, (double)MaxStoredSide / Math.Max(img.Width, img.Height));
                    int w = Math.Max(1, (int)Math.Round(img.Width * scale));
                    int h = Math.Max(1, (int)Math.Round(img.Height * scale));

                    using (var bmp = new Bitmap(w, h))
                    using (var g = Graphics.FromImage(bmp))
                    using (var output = new MemoryStream())
                    {
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.SmoothingMode = SmoothingMode.HighQuality;
                        g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                        g.DrawImage(img, 0, 0, w, h);
                        bmp.Save(output, ImageFormat.Png);
                        return output.ToArray();
                    }
                }
            }
            catch (ArgumentException)
            {
                throw new InvalidOperationException("The file is not a valid picture.");
            }
            catch (OutOfMemoryException)
            {
                throw new InvalidOperationException("The file is not a valid picture.");
            }
        }

        /// <summary>Turns stored bytes into an Image that does not depend on the original stream.</summary>
        public static Image FromBytes(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0) return null;
            try
            {
                using (var ms = new MemoryStream(bytes))
                using (var img = Image.FromStream(ms))
                    return new Bitmap(img);
            }
            catch (ArgumentException)
            {
                return null;
            }
        }
    }
}
