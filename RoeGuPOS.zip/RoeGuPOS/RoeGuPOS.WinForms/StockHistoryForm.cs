using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using RoeGuPOS.Domain;
using RoeGuPOS.Services;

namespace RoeGuPOS.WinForms
{
    /// <summary>Read-only history of stock changes (initial stock, sales, adjustments). Newest first, up to 500 rows.</summary>
    public sealed class StockHistoryForm : Form
    {
        private readonly StockHistoryService service;
        private readonly Product product;
        private readonly CheckBox chkAll = new CheckBox();
        private readonly Label lblTitle = new Label();
        private readonly Label lblCount = new Label();
        private readonly DataGridView grid = new DataGridView();
        private List<StockMovement> current = new List<StockMovement>();

        /// <param name="product">Show this product's history first; null shows every product.</param>
        public StockHistoryForm(User user, Product product)
        {
            service = new StockHistoryService(user);
            this.product = product;

            Text = "Stock history";
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;
            MinimizeBox = false;
            ClientSize = new Size(900, 520);
            MinimumSize = new Size(640, 360);
            Font = Theme.Base(10f);
            BackColor = Theme.Background;
            ForeColor = Theme.Slate;

            var top = new Panel { Dock = DockStyle.Top, Height = 74, Padding = new Padding(16, 10, 16, 0) };
            lblTitle.Font = Theme.Bold(14f);
            lblTitle.AutoSize = true;
            lblTitle.Location = new Point(16, 10);
            chkAll.Text = "All products";
            chkAll.AutoSize = true;
            chkAll.Location = new Point(18, 44);
            chkAll.Checked = product == null;
            chkAll.Enabled = product != null;
            chkAll.CheckedChanged += (s, e) => ReloadData();
            top.Controls.Add(lblTitle);
            top.Controls.Add(chkAll);

            var btnClose = new Button { Text = "Close", Size = new Size(100, 34), Anchor = AnchorStyles.Top | AnchorStyles.Right };
            btnClose.Location = new Point(top.Width - 120, 14);
            Theme.Soft(btnClose);
            btnClose.Click += (s, e) => Close();
            top.Controls.Add(btnClose);

            lblCount.Dock = DockStyle.Bottom;
            lblCount.Height = 28;
            lblCount.ForeColor = Theme.Muted;
            lblCount.Padding = new Padding(16, 5, 0, 0);

            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.RowHeadersVisible = false;
            grid.AutoGenerateColumns = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            Theme.StyleGrid(grid);
            grid.Columns.Add(Col("CreatedAt", "When", 150, "g"));
            grid.Columns.Add(Col("Sku", "SKU", 90, null));
            grid.Columns.Add(Col("ProductName", "Product", 190, null));
            grid.Columns.Add(Col("ChangeQty", "Change", 80, "+0;-0;0"));
            grid.Columns.Add(Col("Reason", "Reason", 0, null));
            grid.Columns.Add(Col("UserName", "By", 140, null));
            grid.Columns["Reason"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            grid.Columns["ChangeQty"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            grid.CellFormatting += (s, e) =>
            {
                if (e.RowIndex < 0 || e.RowIndex >= current.Count) return;
                if (grid.Columns[e.ColumnIndex].Name == "ChangeQty" && current[e.RowIndex].ChangeQty < 0)
                    e.CellStyle.ForeColor = Theme.Rose;
            };

            var host = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16, 0, 16, 0) };
            host.Controls.Add(grid);

            Controls.Add(host);
            Controls.Add(lblCount);
            Controls.Add(top);

            Load += (s, e) => ReloadData();
        }

        private static DataGridViewTextBoxColumn Col(string property, string header, int width, string format)
        {
            var c = new DataGridViewTextBoxColumn { DataPropertyName = property, HeaderText = header, Name = property };
            if (width > 0) c.Width = width;
            if (format != null) c.DefaultCellStyle.Format = format;
            return c;
        }

        private void ReloadData()
        {
            bool all = product == null || chkAll.Checked;
            lblTitle.Text = all ? "Stock history: all products" : "Stock history: " + product.Name;
            try
            {
                current = service.Get(all ? (int?)null : product.ProductId);
                grid.DataSource = null;
                grid.DataSource = current;
                lblCount.Text = current.Count + " movement(s)" + (current.Count >= 500 ? " (showing the newest 500)" : "");
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Could not load the history.\n\n" + ex.Message, "Stock history",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
